package com.harindra.iptvpro

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.PictureInPictureParams
import android.content.ComponentCallbacks2
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.util.Rational
import android.util.SparseIntArray
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.MemoryCategory
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.Arrays
import java.util.Locale

data class TvThemePalette(
    val name: String,
    val subtitle: String,
    val accentHex: String,
    val badgeTextHex: String,
    val statusHex: String,
    val activeRowDrawableRes: Int
)

data class GlassModalOption(
    val iconRes: Int,
    val title: String,
    val subtitle: String,
    val badgeText: String = "",
    val isHighlighted: Boolean = false,
    val onClick: () -> Unit
)

data class GlassFormFieldSpec(
    val label: String,
    val hint: String,
    val iconRes: Int,
    val initialValue: String = "",
    val inputType: Int = InputType.TYPE_CLASS_TEXT
)

enum class BufferProfile(
    val id: String,
    val label: String,
    val subtitle: String,
    val minBufferMs: Int,
    val maxBufferMs: Int,
    val playBufferMs: Int,
    val rebufferMs: Int,
    val targetBytes: Int,
    val prioritizeTimeOverSize: Boolean
) {
    LOW_MEMORY_512MB(
        "LOW_MEM",
        "Hyper-Glass 512MB (150ms Start • 3.5MB Cap)",
        "Default for 512MB RAM Smart TVs • Fast start with anti-stall guard",
        2000, 6800, 150, 500, 3584 * 1024, false
    ),
    ULTRA_FAST_ZAP(
        "ULTRA_ZAP",
        "Turbo Zap 512MB (90ms Start • 3.2MB Cap)",
        "Instant channel switching on strong broadband Wi-Fi / Ethernet",
        1800, 5800, 90, 360, 3276 * 1024, false
    ),
    LOW_LATENCY(
        "LOW_LATENCY",
        "Extreme Sports Zap (60ms Start • 3MB Cap)",
        "Minimum live broadcast edge delay for live cricket & football",
        1600, 5000, 60, 260, 3 * 1024 * 1024, false
    ),
    BALANCED(
        "BALANCED",
        "Balanced HD (120ms Start • 8MB Cap)",
        "Ideal for Android phones & 1GB+ RAM TVs",
        3800, 11000, 120, 450, 8 * 1024 * 1024, false
    ),
    STABLE(
        "STABLE",
        "Stable Shield (320ms Start • 12MB Cap)",
        "Maximum cushion against fluctuating mobile hotspot / slow Wi-Fi",
        6000, 18000, 320, 950, 12 * 1024 * 1024, true
    );

    companion object {
        fun fromId(id: String?, isLowRamDevice: Boolean): BufferProfile {
            return entries.firstOrNull { it.id == id }
                ?: if (isLowRamDevice) LOW_MEMORY_512MB else BALANCED
        }
    }
}

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var exoPlayer: ExoPlayer? = null
    private var sharedAllocator: DefaultAllocator? = null
    private var hlsChunklessFactory: HlsMediaSource.Factory? = null
    private var defaultMediaSourceFactory: DefaultMediaSourceFactory? = null
    private var lastSwitchUsedPreload: Boolean = false
    private var activePlaybackToken: Long = 0L

    private lateinit var playerView: PlayerView
    private lateinit var topControlBar: View
    private lateinit var leftChannelDrawer: View
    private lateinit var channelListRecycler: RecyclerView
    private lateinit var tvEmptyDrawer: TextView
    private lateinit var osdBanner: View
    private lateinit var tvChannelNumber: TextView
    private lateinit var tvChannelName: TextView
    private lateinit var tvChannelCategory: TextView
    private lateinit var tvOsdStreamBadge: TextView
    private lateinit var tvEpgNow: TextView
    private lateinit var osdLiveProgressBar: ProgressBar
    private lateinit var tvActiveSectionBadge: TextView
    private lateinit var btnToggleFavorite: Button
    private lateinit var btnRecallChannel: Button
    private lateinit var btnToggleDrawer: Button
    private lateinit var tabAllChannels: Button
    private lateinit var tabFavorites: Button
    private lateinit var tabRecent: Button
    private lateinit var channelSearch: EditText
    private lateinit var categoryFilter: Spinner
    private lateinit var channelLogo: ImageView

    // DTH Set-Top-Box Startup Overlay Views
    private lateinit var dthBootOverlay: View
    private lateinit var vSignalWaveOuter: View
    private lateinit var vSignalWaveInner: View
    private lateinit var tvBootHeadline: TextView
    private lateinit var tvBootStageStatus: TextView
    private lateinit var tvBootSubDetail: TextView
    private lateinit var bootProgressBar: ProgressBar
    private var outerWaveAnimator: ObjectAnimator? = null
    private var innerWaveAnimator: ObjectAnimator? = null
    private var satellitePulseAnimator: ObjectAnimator? = null
    private var isBootOverlayVisible: Boolean = true
    private var hasRenderedVideoFrame: Boolean = false

    // Real Startup & Runtime Diagnostic Timings
    private var processStartElapsedMs: Long = 0L
    private var firstUiFrameMs: Long = 0L
    private var bootReadyElapsedMs: Long = 0L
    private var firstVideoFrameMs: Long = 0L
    private var lastPlaylistLoadDurationMs: Long = 0L
    private var lastSwitchStartElapsedMs: Long = 0L
    private var lastChannelSwitchMs: Long = 0L
    private var lastZapForward: Boolean = true
    private var isLowRamTvDevice: Boolean = true
    private var totalDeviceRamMb: Long = 512L
    private var maxPlaylistLimit: Int = 60_000

    private lateinit var channelAdapter: ChannelDrawerAdapter
    private var searchQuery: String = ""
    private var selectedCategory: String = "All categories"
    private var suppressCategoryCallback: Boolean = false
    private var epgMap: Map<String, Pair<String, String>> = emptyMap()

    // Primitive IntArray Windowed Pagination
    private var fullFilteredIndices: IntArray = IntArray(0)
    private var currentPagedLimit: Int = 1200
    private val pageStepSize: Int = 1200

    private var filterJob: Job? = null
    private var loadChannelsJob: Job? = null
    private var epgLoadJob: Job? = null
    private var bgSyncJob: Job? = null

    private val xtreamRepo = XtreamRepository()
    private lateinit var profileStore: ProfileStore
    private lateinit var channelCache: ChannelCacheStore
    private lateinit var epgCache: EpgCacheStore
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallbackRegistered: Boolean = false

    private var activeSourceType: ProfileType? = null
    private var activeXtreamCreds: XtreamCredentials? = null
    private var activeM3uInput: String = ""
    private var activeM3uLabel: String = "M3U"

    private var liveResolutionLabel: String = "Auto HD"
    private var liveTelemetryDetail: String = ""
    private var liveStatusLabel: String = "🟢 Live"
    private var subtitlesEnabled: Boolean = false
    private var selectedQualityLabel: String = "Auto"
    private var activeBufferProfile: BufferProfile = BufferProfile.LOW_MEMORY_512MB
    private var autoBootEnabled: Boolean = true
    private var autoResumeEnabled: Boolean = true
    private var currentPlayingStreamUrl: String = ""
    private var usingBackupStream: Boolean = false
    private var unlockedSessionCategories: MutableSet<String> = HashSet()

    // Ultra-Compact RGB_565 80x80 Glide options with 3D Live TV vector placeholder
    private val logoRequestOptions by lazy {
        RequestOptions()
            .format(DecodeFormat.PREFER_RGB_565)
            .override(80, 80)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .dontAnimate()
            .dontTransform()
            .placeholder(R.drawable.ic_3d_live_tv)
            .error(R.drawable.ic_3d_live_tv)
    }

    private val themes = listOf(
        TvThemePalette("Cyan 4D Cyber Crystal", "Electric Sapphire Glow • Default Studio", "#0284C7", "#38BDF8", "#34D399", R.drawable.bg_btn_3d_cyan),
        TvThemePalette("Royal Gold 4D VIP", "Luxury Amber-Gold Bevel & Warm Highlights", "#D97706", "#FBBF24", "#FDE047", R.drawable.bg_btn_3d_gold),
        TvThemePalette("Emerald 4D Matrix", "Bio-Neon Emerald Glass & Mint Status", "#059669", "#34D399", "#6EE7B7", R.drawable.bg_btn_3d_emerald),
        TvThemePalette("Purple 4D Synthwave", "Deep Amethyst Neon & Cyber Violet Rim", "#7C3AED", "#C084FC", "#38BDF8", R.drawable.bg_btn_3d_purple),
        TvThemePalette("Crimson 4D Cinema", "Ruby Velvet Broadcast & Rose-Gold Sheen", "#E11D48", "#FB7185", "#FBBF24", R.drawable.bg_btn_3d_crimson)
    )
    private var currentThemeIndex: Int = 0

    private val playlistPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                Log.w("StreamX", "Persistable URI permission note: ${e.message}")
            }
            importLocalM3uUri(uri)
        }
    }

    private val uiHandler = Handler(Looper.getMainLooper())

    private val hideOsdRunnable: Runnable = Runnable {
        osdBanner.animate()
            .alpha(0f)
            .setDuration(140L)
            .withLayer()
            .withEndAction {
                osdBanner.visibility = View.GONE
                osdBanner.alpha = 1f
            }
            .start()
        if (leftChannelDrawer.visibility != View.VISIBLE) {
            topControlBar.visibility = View.GONE
        }
    }

    // 25ms ultra-fast debounce during rapid TV remote key-repeat zapping
    private var pendingCommitToken: Long = 0L
    private val commitPlaybackRunnable: Runnable = Runnable {
        if (pendingCommitToken == activePlaybackToken) {
            startPlaybackForCurrentChannel(forceReload = false)
        }
    }

    private val retryPlaybackRunnable: Runnable = Runnable {
        val player = exoPlayer ?: return@Runnable
        if (allChannels.isNotEmpty()) {
            player.seekToDefaultPosition()
            player.prepare()
            player.playWhenReady = true
        }
    }

    // Live Heap Guard (<16MB free + unallocated JVM heap check)
    private val heapGuardRunnable: Runnable = object : Runnable {
        override fun run() {
            val rt = Runtime.getRuntime()
            val freeAndUnallocated = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
            if (freeAndUnallocated < 16L * 1024L * 1024L) {
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                sharedAllocator?.trim()
                runCatching { Glide.get(this@PlayerActivity).clearMemory() }
            }
            uiHandler.postDelayed(this, 5000L)
        }
    }

    // Fast 2.5s Playback Stall Watchdog + Smart Auto-Failover to backupUrl
    private var stallRecoveryCount: Int = 0
    private val stallWatchdogRunnable: Runnable = object : Runnable {
        override fun run() {
            val player = exoPlayer ?: return
            if (player.playbackState == Player.STATE_BUFFERING && allChannels.isNotEmpty()) {
                val ch = allChannels.getOrNull(currentChannelIndex)
                if (ch != null && !usingBackupStream && ch.backupUrl.isNotBlank()) {
                    usingBackupStream = true
                    stallRecoveryCount = 0
                    Log.w("StreamX", "2.5s Watchdog failover to backupUrl for ${ch.name}")
                    liveStatusLabel = "⚡ Backup Stream"
                    updateOsdForCurrentChannel()
                    playSpecificStreamUrl(ch.backupUrl)
                    return
                }
                if (stallRecoveryCount < 3) {
                    StreamPreFetcher.updateNetworkState(connected = true, degraded = true)
                    stallRecoveryCount++
                    Log.w("StreamX", "2.5s Stall Watchdog triggered (${stallRecoveryCount}/3): reconnecting live edge")
                    liveStatusLabel = "🔄 Fast Recovery ${stallRecoveryCount}/3..."
                    updateOsdForCurrentChannel()
                    player.seekToDefaultPosition()
                    player.prepare()
                    player.playWhenReady = true
                    uiHandler.postDelayed(this, 3000L)
                } else {
                    liveStatusLabel = "⚠️ Slow Server / Stream Stalled"
                    updateOsdForCurrentChannel()
                }
            }
        }
    }

    // Safety guard so user is never permanently stuck on the DTH startup overlay
    private val dismissBootSafetyRunnable: Runnable = Runnable {
        if (hasRenderedVideoFrame) return@Runnable
        if (allChannels.isNotEmpty()) {
            liveStatusLabel = "⏳ Connecting..."
            updateOsdForCurrentChannel()
            showZappingOsd()
            dismissDthBootOverlay("PLAYER READY • CONNECTING")
        } else {
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
        }
    }

    private val persistStateRunnable: Runnable = Runnable {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return@Runnable
        val ch = allChannels[currentChannelIndex]
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE).edit()
            .putString("recent_ids", recentIds.joinToString("\n"))
            .putString("last_channel_id", ch.id)
            .putInt("last_channel_index", currentChannelIndex)
            .apply()
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            StreamPreFetcher.updateNetworkState(connected = true, degraded = false)
            uiHandler.post {
                val player = exoPlayer ?: return@post
                if (allChannels.isNotEmpty() &&
                    (player.playbackState == Player.STATE_IDLE || liveStatusLabel.startsWith("⚠️") || liveStatusLabel.startsWith("🔄"))
                ) {
                    playbackRetryCount = 0
                    stallRecoveryCount = 0
                    liveStatusLabel = "🔄 Network Restored..."
                    updateOsdForCurrentChannel()
                    player.seekToDefaultPosition()
                    player.prepare()
                    player.playWhenReady = true
                }
            }
        }

        override fun onLost(network: Network) {
            StreamPreFetcher.updateNetworkState(connected = false)
            uiHandler.post {
                liveStatusLabel = "⚠️ Waiting for Network..."
                updateOsdForCurrentChannel()
            }
        }
    }

    private var allChannels: List<Channel> = listOf(
        Channel("1", 1, "Sports 18 HD (Test Stream)", "Sports", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
        Channel("2", 2, "Cinema Gold 4K Stream", "Movies", "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8"),
        Channel("3", 3, "Bharat News 24x7 HD", "News", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"),
        Channel("4", 4, "Music Beats Dolby HD", "Music", "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8")
    )
    private var allSequentialIndices: IntArray = IntArray(4) { it }
    private var channelsByCategory: Map<String, IntArray> = emptyMap()
    private var channelIndexById: Map<String, Int> = emptyMap()
    private var nonSequentialNumberMap: SparseIntArray = SparseIntArray(0)
    private var knownEpgAndChannelIds: Set<String> = emptySet()

    private var favoriteIds: MutableSet<String> = mutableSetOf("1")
    private var recentIds: MutableList<String> = mutableListOf()
    private var activeTab: String = "ALL"

    private var currentChannelIndex: Int = 0
    private var previousChannelIndex: Int = 0
    private var playbackRetryCount: Int = 0
    private var resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private var currentResizeIndex = 0
    private var sleepMinutes = 0
    private val sleepRunnable: Runnable = Runnable {
        exoPlayer?.pause()
        Toast.makeText(this, "Sleep Timer: Playback Paused", Toast.LENGTH_LONG).show()
    }

    // Direct O(1) Channel Number Entry with 0.75s (750ms) Auto-Tune Timer
    private var numberInputBuffer: String = ""
    private val numberJumpRunnable: Runnable = Runnable {
        val targetNum = numberInputBuffer.toIntOrNull()
        numberInputBuffer = ""
        if (targetNum != null) {
            val idx = findChannelIndexByNumberFast(targetNum)
            if (idx != -1) {
                switchChannel(idx, immediatePlayback = true)
            } else {
                Toast.makeText(this, "Channel #$targetNum not found", Toast.LENGTH_SHORT).show()
                updateOsdForCurrentChannel()
            }
        }
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()

    private fun findChannelIndexByNumberFast(targetNum: Int): Int {
        val directIdx = targetNum - 1
        if (directIdx in allChannels.indices && allChannels[directIdx].number == targetNum) {
            return directIdx
        }
        val mapped = nonSequentialNumberMap.get(targetNum, -1)
        if (mapped != -1 && mapped in allChannels.indices) return mapped
        return allChannels.indexOfFirst { it.number == targetNum }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        processStartElapsedMs = SystemClock.elapsedRealtime()
        hasRenderedVideoFrame = false
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        dthBootOverlay = findViewById(R.id.dthBootOverlay)
        vSignalWaveOuter = findViewById(R.id.vSignalWaveOuter)
        vSignalWaveInner = findViewById(R.id.vSignalWaveInner)
        tvBootHeadline = findViewById(R.id.tvBootHeadline)
        tvBootStageStatus = findViewById(R.id.tvBootStageStatus)
        tvBootSubDetail = findViewById(R.id.tvBootSubDetail)
        bootProgressBar = findViewById(R.id.bootProgressBar)

        detectDeviceMemoryProfile()
        runCatching { Glide.get(this).setMemoryCategory(MemoryCategory.LOW) }

        startDthBootSignalAnimation()
        updateBootStage(8, "Starting StreamX v14.0 Hyper-Glass 4D...", "Fast SXB2 Cache • 512MB Low-RAM Guard")

        findViewById<Button>(R.id.btnProfiles).setOnClickListener { showProfilesDialog() }
        playerView = findViewById(R.id.media3PlayerView)
        playerView.keepScreenOn = true
        topControlBar = findViewById(R.id.topControlBar)
        leftChannelDrawer = findViewById(R.id.leftChannelDrawer)
        channelListRecycler = findViewById(R.id.channelListRecycler)
        tvEmptyDrawer = findViewById(R.id.tvEmptyDrawer)
        osdBanner = findViewById(R.id.zappingOsdContainer)
        tvChannelNumber = findViewById(R.id.tvChannelNumber)
        tvChannelName = findViewById(R.id.tvChannelName)
        tvChannelCategory = findViewById(R.id.tvChannelCategory)
        tvOsdStreamBadge = findViewById(R.id.tvOsdStreamBadge)
        tvEpgNow = findViewById(R.id.tvEpgNow)
        osdLiveProgressBar = findViewById(R.id.osdLiveProgressBar)
        tvActiveSectionBadge = findViewById(R.id.tvActiveSectionBadge)
        btnToggleFavorite = findViewById(R.id.btnToggleFavorite)
        btnRecallChannel = findViewById(R.id.btnRecallChannel)
        btnToggleDrawer = findViewById(R.id.btnToggleDrawer)
        tabAllChannels = findViewById(R.id.tabAllChannels)
        tabFavorites = findViewById(R.id.tabFavorites)
        tabRecent = findViewById(R.id.tabRecent)
        channelSearch = findViewById(R.id.channelSearch)
        categoryFilter = findViewById(R.id.categoryFilter)
        channelLogo = findViewById(R.id.channelLogo)

        channelAdapter = ChannelDrawerAdapter(
            channelProvider = { idx -> allChannels.getOrNull(idx) },
            isFavorite = { id -> favoriteIds.contains(id) },
            epgProvider = { ch -> lookupEpgForChannel(ch)?.first },
            logoOptions = logoRequestOptions,
            onChannelClick = { globalIdx -> switchChannel(globalIdx, immediatePlayback = true) },
            onChannelFocused = { globalIdx ->
                val focusedCh = allChannels.getOrNull(globalIdx)
                if (focusedCh != null && focusedCh.streamUrl != currentPlayingStreamUrl) {
                    StreamPreFetcher.scheduleFocusPrefetch(
                        this@PlayerActivity,
                        focusedCh.streamUrl,
                        hlsChunklessFactory,
                        defaultMediaSourceFactory
                    )
                }
            }
        )
        val linearLm = LinearLayoutManager(this)
        channelListRecycler.layoutManager = linearLm
        channelListRecycler.setHasFixedSize(true)
        val cacheViews = if (isLowRamTvDevice) 5 else 8
        val poolViews = if (isLowRamTvDevice) 10 else 14
        channelListRecycler.setItemViewCacheSize(cacheViews)
        channelListRecycler.recycledViewPool.setMaxRecycledViews(0, poolViews)
        channelListRecycler.itemAnimator = null
        channelListRecycler.adapter = channelAdapter

        channelListRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                runCatching {
                    if (newState == RecyclerView.SCROLL_STATE_SETTLING) {
                        Glide.with(this@PlayerActivity).pauseRequests()
                    } else {
                        Glide.with(this@PlayerActivity).resumeRequests()
                    }
                }
            }

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy <= 0) return
                val totalLoadedInAdapter = channelAdapter.itemCount
                if (totalLoadedInAdapter < fullFilteredIndices.size) {
                    val lastVisible = linearLm.findLastVisibleItemPosition()
                    if (lastVisible >= totalLoadedInAdapter - 25) {
                        currentPagedLimit = (currentPagedLimit + pageStepSize).coerceAtMost(fullFilteredIndices.size)
                        channelAdapter.submitIndices(
                            fullFilteredIndices.copyOfRange(0, currentPagedLimit),
                            currentChannelIndex,
                            null
                        )
                    }
                }
            }
        })

        setupUiListeners()

        window.decorView.post {
            firstUiFrameMs = SystemClock.elapsedRealtime() - processStartElapsedMs
            startStagedBootSequence()
        }
    }

    private fun detectDeviceMemoryProfile() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (am != null) {
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            totalDeviceRamMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(256L)
            isLowRamTvDevice = am.isLowRamDevice || totalDeviceRamMb <= 850L
        } else {
            isLowRamTvDevice = true
        }
        maxPlaylistLimit = 60_000
    }

    private fun startDthBootSignalAnimation() {
        val satellite = findViewById<View>(R.id.ivBootSatellite)
        satellite.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        satellitePulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
            satellite,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 0.97f, 1.03f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.97f, 1.03f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.88f, 1.0f)
        ).apply {
            duration = 2200L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        if (isLowRamTvDevice) return
        val scaleXOuter = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.90f, 1.10f)
        val scaleYOuter = PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.90f, 1.10f)
        val alphaOuter = PropertyValuesHolder.ofFloat(View.ALPHA, 0.70f, 0.20f)
        outerWaveAnimator = ObjectAnimator.ofPropertyValuesHolder(
            vSignalWaveOuter,
            scaleXOuter,
            scaleYOuter,
            alphaOuter
        ).apply {
            duration = 1500L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            start()
        }

        val alphaInner = PropertyValuesHolder.ofFloat(View.ALPHA, 0.40f, 0.85f)
        innerWaveAnimator = ObjectAnimator.ofPropertyValuesHolder(
            vSignalWaveInner,
            alphaInner
        ).apply {
            duration = 1100L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun cancelBootAnimators() {
        outerWaveAnimator?.cancel()
        innerWaveAnimator?.cancel()
        satellitePulseAnimator?.cancel()
        outerWaveAnimator = null
        innerWaveAnimator = null
        satellitePulseAnimator = null
    }

    private fun updateBootStage(progress: Int, stageText: String, subDetail: String? = null) {
        if (!isBootOverlayVisible) return
        bootProgressBar.progress = progress.coerceIn(0, 100)
        tvBootStageStatus.text = stageText
        if (subDetail != null) {
            tvBootSubDetail.text = subDetail
        }
    }

    private fun dismissDthBootOverlay(finalMessage: String = "READY TO WATCH") {
        if (!isBootOverlayVisible) return
        isBootOverlayVisible = false
        uiHandler.removeCallbacks(dismissBootSafetyRunnable)
        bootReadyElapsedMs = SystemClock.elapsedRealtime() - processStartElapsedMs
        bootProgressBar.progress = 100
        tvBootHeadline.text = finalMessage
        tvBootStageStatus.text = "StreamX v14.0 Ready • ${bootReadyElapsedMs}ms"
        cancelBootAnimators()
        dthBootOverlay.animate()
            .alpha(0f)
            .setDuration(150L)
            .withLayer()
            .withEndAction {
                dthBootOverlay.visibility = View.GONE
                dthBootOverlay.alpha = 1f
            }
            .start()
    }

    private fun isNetworkConnectedNow(): Boolean {
        val cm = connectivityManager ?: return true
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val net = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(net) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun startStagedBootSequence() {
        uiHandler.postDelayed(dismissBootSafetyRunnable, 20_000L)
        uiHandler.postDelayed(heapGuardRunnable, 5000L)

        lifecycleScope.launch {
            updateBootStage(
                20,
                "Loading saved settings...",
                "RAM Profile: ${totalDeviceRamMb}MB (${if (isLowRamTvDevice) "512MB Hyper-Glass" else "Standard"})"
            )
            val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            val bootSettings = withContext(Dispatchers.IO) {
                profileStore = ProfileStore(this@PlayerActivity)
                channelCache = ChannelCacheStore(this@PlayerActivity)
                epgCache = EpgCacheStore(this@PlayerActivity)

                val favs = prefs.getStringSet("fav_ids", null)?.toHashSet() ?: hashSetOf("1")
                val recents = prefs.getString("recent_ids", "")
                    ?.lines()
                    ?.filter { it.isNotBlank() }
                    ?.take(20) ?: emptyList()
                val themeIdx = prefs.getInt("theme_index", 0)
                val bufId = prefs.getString("buffer_profile_id", null)
                val autoBoot = prefs.getBoolean("auto_boot_enabled", true)
                val autoResume = prefs.getBoolean("auto_resume_enabled", true)
                val savedEpgUrl = prefs.getString("last_epg_url", "") ?: ""
                val cachedEpg = epgCache.loadEpg()

                BootSettingsBundle(
                    favs = favs,
                    recents = recents,
                    themeIndex = themeIdx,
                    bufferProfile = BufferProfile.fromId(bufId, isLowRamTvDevice),
                    autoBoot = autoBoot,
                    autoResume = autoResume,
                    savedEpgUrl = savedEpgUrl,
                    cachedEpg = cachedEpg
                )
            }

            favoriteIds.clear()
            favoriteIds.addAll(bootSettings.favs)
            recentIds.clear()
            recentIds.addAll(bootSettings.recents)
            activeBufferProfile = bootSettings.bufferProfile
            autoBootEnabled = bootSettings.autoBoot
            autoResumeEnabled = bootSettings.autoResume
            applyTheme(bootSettings.themeIndex)

            if (bootSettings.cachedEpg != null) {
                epgMap = bootSettings.cachedEpg.entries
            }

            updateBootStage(
                45,
                "Initializing Direct-RAM Media Engine...",
                "Buffer: ${activeBufferProfile.label}"
            )
            initializeMedia3ProEngine()
            rebuildChannelIndicesSync(allChannels)

            val hasNet = isNetworkConnectedNow()
            val epgUrlToRefresh = bootSettings.savedEpgUrl.ifBlank { bootSettings.cachedEpg?.sourceUrl.orEmpty() }
            if (hasNet && epgUrlToRefresh.isNotBlank()) {
                val epgAge = System.currentTimeMillis() - (bootSettings.cachedEpg?.timestampMs ?: 0L)
                if (epgAge > EpgCacheStore.EPG_REFRESH_INTERVAL_MS) {
                    loadXmltvEpg(epgUrlToRefresh, silentBackground = true)
                }
            }

            updateBootStage(65, "Restoring Channels from Fast SXB2 Cache...", "Instant Direct-RAM Boot")
            restoreSavedDataFromBoot(prefs, hasNet)
        }
    }

    private data class BootSettingsBundle(
        val favs: Set<String>,
        val recents: List<String>,
        val themeIndex: Int,
        val bufferProfile: BufferProfile,
        val autoBoot: Boolean,
        val autoResume: Boolean,
        val savedEpgUrl: String,
        val cachedEpg: CachedEpgData?
    )

    private fun updateTabButton3dSelection(selectedTab: String) {
        val activeRes = themes[currentThemeIndex].activeRowDrawableRes
        tabAllChannels.setBackgroundResource(if (selectedTab == "ALL") activeRes else R.drawable.bg_btn_3d_slate)
        tabFavorites.setBackgroundResource(if (selectedTab == "FAV") R.drawable.bg_btn_3d_gold else R.drawable.bg_btn_3d_slate)
        tabRecent.setBackgroundResource(if (selectedTab == "RECENT") activeRes else R.drawable.bg_btn_3d_slate)
    }

    private fun createGlassCategoryAdapter(categories: List<String>): ArrayAdapter<String> {
        return object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@PlayerActivity).apply {
                    setSingleLine(true)
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                    textSize = 12.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#E0F2FE"))
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_3d_category, 0, 0, 0)
                    compoundDrawablePadding = dp(8)
                }
                val item = getItem(position) ?: "All categories"
                tv.text = "Category: $item"
                return tv
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@PlayerActivity).apply {
                    setSingleLine(true)
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(14), dp(11), dp(14), dp(11))
                    setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_3d_category, 0, 0, 0)
                    compoundDrawablePadding = dp(10)
                }
                val item = getItem(position) ?: "All categories"
                val isSelected = item == selectedCategory
                tv.text = if (isSelected) "● $item  ✓" else item
                tv.setTextColor(if (isSelected) Color.parseColor("#38BDF8") else Color.parseColor("#F8FAFC"))
                tv.setBackgroundColor(if (isSelected) Color.parseColor("#FF0D213F") else Color.parseColor("#FF071022"))
                return tv
            }
        }
    }

    private fun setupUiListeners() {
        channelSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString().orEmpty()
                renderDrawerList(debounceMs = 120L)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        categoryFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressCategoryCallback) return
                selectedCategory = parent?.getItemAtPosition(position)?.toString() ?: "All categories"
                renderDrawerList()
            }
        }

        btnToggleDrawer.setOnClickListener {
            if (leftChannelDrawer.visibility == View.VISIBLE) {
                closeDrawerAndRestoreFocus()
            } else {
                openDrawerAndRequestFocus()
            }
        }
        tabAllChannels.setOnClickListener {
            activeTab = "ALL"
            updateTabButton3dSelection("ALL")
            tvActiveSectionBadge.text = "StreamX Pro • All Live TV (${allChannels.size})"
            renderDrawerList()
        }
        tabFavorites.setOnClickListener {
            activeTab = "FAV"
            updateTabButton3dSelection("FAV")
            tvActiveSectionBadge.text = "StreamX Pro • ★ Favorites (${favoriteIds.size})"
            renderDrawerList()
        }
        tabRecent.setOnClickListener {
            activeTab = "RECENT"
            updateTabButton3dSelection("RECENT")
            tvActiveSectionBadge.text = "StreamX Pro • Recent Watched"
            renderDrawerList()
        }

        findViewById<Button>(R.id.btnXtreamLogin).setOnClickListener { showXtreamLoginDialog() }
        findViewById<Button>(R.id.btnM3uLoad).setOnClickListener { showM3uLoadDialog() }
        findViewById<Button>(R.id.btnRefreshChannels).setOnClickListener { forceRefreshActivePlaylist() }
        findViewById<Button>(R.id.btnAudioQuality).setOnClickListener { showAudioAndQualityDialog() }
        findViewById<Button>(R.id.btnThemeToggle).setOnClickListener { showThemeAndPipDialog() }

        findViewById<Button>(R.id.btnZapUp).setOnClickListener {
            lastZapForward = true
            switchChannel(currentChannelIndex + 1, immediatePlayback = true)
        }
        findViewById<Button>(R.id.btnZapDown).setOnClickListener {
            lastZapForward = false
            switchChannel(currentChannelIndex - 1, immediatePlayback = true)
        }
        btnRecallChannel.setOnClickListener { recallPreviousChannel() }
        btnToggleFavorite.setOnClickListener { toggleCurrentChannelFavorite() }

        findViewById<Button>(R.id.btnEpg).setOnClickListener { showEpgUrlDialog() }

        val btnSleep = findViewById<Button>(R.id.btnSleepTimer)
        btnSleep.setOnLongClickListener { showEpgUrlDialog(); true }
        btnSleep.setOnClickListener {
            sleepMinutes = when (sleepMinutes) {
                0 -> 15
                15 -> 30
                30 -> 60
                60 -> 90
                else -> 0
            }
            uiHandler.removeCallbacks(sleepRunnable)
            if (sleepMinutes > 0) {
                uiHandler.postDelayed(sleepRunnable, sleepMinutes * 60 * 1000L)
                btnSleep.text = "Sleep: ${sleepMinutes}m"
                Toast.makeText(this, "Sleep Timer set for $sleepMinutes mins", Toast.LENGTH_SHORT).show()
            } else {
                btnSleep.text = "Sleep: OFF"
            }
        }

        val btnAspect = findViewById<Button>(R.id.btnAspectToggle)
        btnAspect.setOnClickListener {
            currentResizeIndex = (currentResizeIndex + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[currentResizeIndex]
            btnAspect.text = when (currentResizeIndex) {
                0 -> "16:9 Fit"
                1 -> "Full Stretch"
                else -> "Cinema Zoom"
            }
        }

        playerView.setOnClickListener {
            if (leftChannelDrawer.visibility == View.VISIBLE) {
                closeDrawerAndRestoreFocus()
            } else {
                showZappingOsd()
            }
        }
    }

    private fun openDrawerAndRequestFocus() {
        leftChannelDrawer.visibility = View.VISIBLE
        topControlBar.visibility = View.VISIBLE
        renderDrawerList(scrollToActive = true, requestFocusOnActive = true)
    }

    private fun closeDrawerAndRestoreFocus() {
        leftChannelDrawer.visibility = View.GONE
        playerView.requestFocus()
    }

    private fun cacheKeyFor(raw: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return bytes.take(12).joinToString("") { "%02x".format(it) }
    }

    private fun rebuildChannelIndicesSync(channels: List<Channel>) {
        val seq = IntArray(channels.size) { it }
        val byId = HashMap<String, Int>(channels.size)
        val nonSeqNum = SparseIntArray()
        val byCatTemp = HashMap<String, ArrayList<Int>>(32)
        val epgIds = HashSet<String>(channels.size * 2)

        for (i in channels.indices) {
            val ch = channels[i]
            if (!byId.containsKey(ch.id)) byId[ch.id] = i
            if (ch.number != i + 1 && nonSeqNum.indexOfKey(ch.number) < 0) {
                nonSeqNum.put(ch.number, i)
            }
            byCatTemp.getOrPut(ch.category.lowercase(Locale.ROOT)) { ArrayList() }.add(i)
            epgIds.add(ch.id)
            if (ch.epgId.isNotEmpty()) epgIds.add(ch.epgId)
        }
        val byCatPrimitive = HashMap<String, IntArray>(byCatTemp.size)
        for ((k, list) in byCatTemp) {
            byCatPrimitive[k] = list.toIntArray()
        }
        allSequentialIndices = seq
        channelIndexById = byId
        nonSequentialNumberMap = nonSeqNum
        channelsByCategory = byCatPrimitive
        knownEpgAndChannelIds = epgIds
    }

    private suspend fun applyLoadedChannels(
        newChannels: List<Channel>,
        sectionTitle: String? = null,
        resumeLastWatched: Boolean = true,
        isPreliminaryBatch: Boolean = false
    ) {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        val shouldResume = resumeLastWatched && autoResumeEnabled
        val savedLastId = if (shouldResume) prefs.getString("last_channel_id", null) else null
        val savedLastIndex = if (shouldResume) prefs.getInt("last_channel_index", 0) else 0

        if (!isPreliminaryBatch) {
            updateBootStage(80, "Indexing ${newChannels.size} Channels...", "Zero-copy primitive arrays")
        }

        val prepared = withContext(Dispatchers.Default) {
            val seq = IntArray(newChannels.size) { it }
            val byId = HashMap<String, Int>(newChannels.size)
            val nonSeqNum = SparseIntArray()
            val byCatTemp = HashMap<String, ArrayList<Int>>(128)
            val categorySet = LinkedHashSet<String>()
            val epgIds = HashSet<String>(newChannels.size.coerceAtMost(15000))

            for (i in newChannels.indices) {
                if (i % 2000 == 0) ensureActive()
                val ch = newChannels[i]
                if (!byId.containsKey(ch.id)) byId[ch.id] = i
                if (ch.number != i + 1 && nonSeqNum.indexOfKey(ch.number) < 0) {
                    nonSeqNum.put(ch.number, i)
                }
                if (ch.category.isNotBlank()) {
                    categorySet.add(ch.category)
                    byCatTemp.getOrPut(ch.category.lowercase(Locale.ROOT)) { ArrayList() }.add(i)
                }
                if (epgIds.size < 25000) {
                    epgIds.add(ch.id)
                    if (ch.epgId.isNotEmpty()) epgIds.add(ch.epgId)
                }
            }
            val byCatPrimitive = HashMap<String, IntArray>(byCatTemp.size)
            for ((k, list) in byCatTemp) {
                byCatPrimitive[k] = list.toIntArray()
            }
            val categories = ArrayList<String>(categorySet.size + 1).apply {
                add("All categories")
                addAll(categorySet.sorted())
            }
            val targetIdx = if (shouldResume) {
                (if (!savedLastId.isNullOrBlank()) byId[savedLastId] else null)
                    ?: savedLastIndex.takeIf { it in newChannels.indices }
                    ?: 0
            } else {
                0
            }
            PreparedChannelData(seq, byId, nonSeqNum, byCatPrimitive, categories, epgIds, targetIdx)
        }

        allChannels = newChannels
        allSequentialIndices = prepared.seq
        channelIndexById = prepared.byId
        nonSequentialNumberMap = prepared.nonSeqNum
        channelsByCategory = prepared.byCat
        knownEpgAndChannelIds = prepared.epgIds

        suppressCategoryCallback = true
        selectedCategory = "All categories"
        categoryFilter.adapter = createGlassCategoryAdapter(prepared.categories)
        categoryFilter.setSelection(0, false)
        suppressCategoryCallback = false

        if (sectionTitle != null) {
            tvActiveSectionBadge.text = sectionTitle
        }

        if (!isPreliminaryBatch || currentPlayingStreamUrl.isEmpty()) {
            previousChannelIndex = prepared.startIndex
            updateBootStage(92, "Starting Live TV...", "Channel #${prepared.startIndex + 1}")
            switchChannel(prepared.startIndex, immediatePlayback = true)
        }

        if (leftChannelDrawer.visibility == View.VISIBLE) {
            renderDrawerList(scrollToActive = true)
        }
    }

    private data class PreparedChannelData(
        val seq: IntArray,
        val byId: Map<String, Int>,
        val nonSeqNum: SparseIntArray,
        val byCat: Map<String, IntArray>,
        val categories: List<String>,
        val epgIds: Set<String>,
        val startIndex: Int
    )

    private fun initializeMedia3ProEngine(recreateIfPresent: Boolean = false) {
        if (exoPlayer != null && !recreateIfPresent) return
        val previousUrl = currentPlayingStreamUrl
        if (recreateIfPresent) {
            playerView.player = null
            exoPlayer?.release()
            exoPlayer = null
            currentPlayingStreamUrl = ""
        }

        val bp = activeBufferProfile
        val allocator = DefaultAllocator(true, 64 * 1024)
        sharedAllocator = allocator
        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(allocator)
            .setBufferDurationsMs(bp.minBufferMs, bp.maxBufferMs, bp.playBufferMs, bp.rebufferMs)
            .setTargetBufferBytes(bp.targetBytes)
            .setBackBuffer(0, false)
            .setPrioritizeTimeOverSizeThresholds(bp.prioritizeTimeOverSize)
            .build()

        // Avoid loading optional software decoder extensions on 512MB TVs; enable async queueing.
        val renderersFactory = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
            .setEnableDecoderFallback(true)

        // Direct-RAM Zero-Disk OkHttpDataSource wrapped with PreloadAwareDataSourceFactory
        val okHttpDataSourceFactory = OkHttpDataSource.Factory(NetworkClient.streamClient)
            .setUserAgent("StreamX-Media3Pro/14.0-HyperGlass (AndroidTV)")
        val preloadAwareFactory = StreamPreFetcher.createPreloadAwareDataSourceFactory(okHttpDataSourceFactory)

        hlsChunklessFactory = HlsMediaSource.Factory(preloadAwareFactory)
            .setAllowChunklessPreparation(true)

        val mediaSourceFactory = DefaultMediaSourceFactory(preloadAwareFactory)
        defaultMediaSourceFactory = mediaSourceFactory

        exoPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .also { player ->
                player.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                playerView.player = player
                playerView.resizeMode = resizeModes[currentResizeIndex]

                val paramsBuilder = player.trackSelectionParameters
                    .buildUpon()
                    .setPreferredAudioLanguages("hi", "hin", "en", "eng")
                if (isLowRamTvDevice && selectedQualityLabel == "Auto") {
                    paramsBuilder
                        .setMaxVideoSize(1920, 1080)
                        .setMaxVideoBitrate(8_000_000)
                }
                player.trackSelectionParameters = paramsBuilder.build()

                player.addListener(object : Player.Listener {
                    override fun onRenderedFirstFrame() {
                        val now = SystemClock.elapsedRealtime()
                        if (firstVideoFrameMs == 0L) {
                            firstVideoFrameMs = now - processStartElapsedMs
                        }
                        if (lastSwitchStartElapsedMs > 0L) {
                            lastChannelSwitchMs = now - lastSwitchStartElapsedMs
                        }
                        hasRenderedVideoFrame = true
                        if (isBootOverlayVisible) {
                            dismissDthBootOverlay("READY TO WATCH")
                        }
                        updateLiveTelemetryBadge(player)
                        updateOsdForCurrentChannel()
                    }

                    override fun onVideoSizeChanged(videoSize: VideoSize) {
                        val h = videoSize.height
                        val w = videoSize.width
                        if (h > 0 && w > 0) {
                            liveResolutionLabel = when {
                                h >= 2160 || w >= 3840 -> "4K UHD"
                                h >= 1080 -> "1080p FHD"
                                h >= 720 -> "720p HD"
                                h >= 540 -> "576p HQ"
                                else -> "${h}p SD"
                            }
                            updateLiveTelemetryBadge(player)
                            updateOsdForCurrentChannel()
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_BUFFERING -> {
                                liveStatusLabel = if (usingBackupStream) "⏳ Backup..." else "⏳ Zap..."
                                osdLiveProgressBar.progress = 55
                                updateOsdForCurrentChannel()
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                uiHandler.postDelayed(stallWatchdogRunnable, 2500L)
                            }
                            Player.STATE_READY -> {
                                playbackRetryCount = 0
                                stallRecoveryCount = 0
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                liveStatusLabel = if (usingBackupStream) "🟢 Live (Backup)" else "🟢 Live"
                                osdLiveProgressBar.progress = 100
                                updateLiveTelemetryBadge(player)
                                updateOsdForCurrentChannel()

                                if (allChannels.size > 1) {
                                    val nextIdx = (currentChannelIndex + 1) % allChannels.size
                                    val prevIdx = (currentChannelIndex - 1 + allChannels.size) % allChannels.size
                                    StreamPreFetcher.scheduleAdjacentPrefetch(
                                        this@PlayerActivity,
                                        allChannels.getOrNull(nextIdx)?.streamUrl,
                                        allChannels.getOrNull(prevIdx)?.streamUrl,
                                        preferForward = lastZapForward,
                                        hlsFactory = hlsChunklessFactory,
                                        defaultMediaSourceFactory = defaultMediaSourceFactory
                                    )
                                }
                            }
                            Player.STATE_ENDED -> {
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                liveStatusLabel = "🔄 Reconnecting..."
                                osdLiveProgressBar.progress = 35
                                updateOsdForCurrentChannel()
                                uiHandler.removeCallbacks(retryPlaybackRunnable)
                                uiHandler.postDelayed(retryPlaybackRunnable, 750L)
                            }
                            Player.STATE_IDLE -> {
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                            }
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        uiHandler.removeCallbacks(stallWatchdogRunnable)
                        Log.w("StreamX", "Playback error (${error.errorCodeName}): ${error.message}")

                        if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                            error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
                        ) {
                            player.trackSelectionParameters = player.trackSelectionParameters
                                .buildUpon()
                                .setMaxVideoSize(1280, 720)
                                .setMaxVideoBitrate(4_000_000)
                                .build()
                        }

                        val activeChannel = allChannels.getOrNull(currentChannelIndex)
                        if (activeChannel != null && !usingBackupStream && activeChannel.backupUrl.isNotBlank()) {
                            usingBackupStream = true
                            playbackRetryCount = 0
                            liveStatusLabel = "⚡ Auto-Failover Backup..."
                            updateOsdForCurrentChannel()
                            playSpecificStreamUrl(activeChannel.backupUrl)
                            return
                        }

                        if (playbackRetryCount >= 3) {
                            liveStatusLabel = "⚠️ Stream Offline"
                            osdLiveProgressBar.progress = 15
                            updateOsdForCurrentChannel()
                            if (isBootOverlayVisible) {
                                dismissDthBootOverlay("READY TO WATCH")
                            }
                            Toast.makeText(
                                this@PlayerActivity,
                                "Stream offline or unreachable. Try another channel or tap Sync.",
                                Toast.LENGTH_LONG
                            ).show()
                            return
                        }
                        playbackRetryCount++
                        val retryNum = playbackRetryCount
                        val backoffMs = 950L * retryNum
                        liveStatusLabel = "🔄 Retry $retryNum/3..."
                        updateOsdForCurrentChannel()
                        uiHandler.removeCallbacks(retryPlaybackRunnable)
                        uiHandler.postDelayed(retryPlaybackRunnable, backoffMs)
                    }
                })
            }

        if (previousUrl.isNotEmpty() && allChannels.isNotEmpty()) {
            startPlaybackForCurrentChannel(forceReload = true)
        }
    }

    private fun updateLiveTelemetryBadge(player: ExoPlayer) {
        val vf = player.videoFormat
        val af = player.audioFormat
        val parts = ArrayList<String>(2)
        if (vf != null) {
            if (vf.frameRate > 0f) {
                parts.add("${vf.frameRate.toInt()}fps")
            }
            if (vf.bitrate > 0) {
                val mbps = vf.bitrate / 1_000_000.0
                parts.add(String.format(Locale.US, "%.1fMbps", mbps))
            }
        }
        liveTelemetryDetail = parts.joinToString(" • ")

        val preloadPrefix = if (lastSwitchUsedPreload) "⚡ PRELOAD" else "⚡"
        val zapTag = if (lastChannelSwitchMs in 1..4999) "$preloadPrefix ${lastChannelSwitchMs}ms" else "$preloadPrefix DIRECT-RAM"
        val audioTag = af?.language?.uppercase(Locale.ROOT)?.takeIf { it.isNotBlank() && it != "UND" } ?: "STEREO"
        tvOsdStreamBadge.text = "$zapTag • $audioTag"
    }

    private fun recallPreviousChannel() {
        if (allChannels.isEmpty()) return
        if (previousChannelIndex != currentChannelIndex && previousChannelIndex in allChannels.indices) {
            val target = previousChannelIndex
            Toast.makeText(this, "⟲ Recall: ${allChannels[target].name}", Toast.LENGTH_SHORT).show()
            switchChannel(target, immediatePlayback = true)
        } else if (recentIds.size >= 2) {
            val prevId = recentIds[1]
            val idx = channelIndexById[prevId]
            if (idx != null && idx != currentChannelIndex) {
                Toast.makeText(this, "⟲ Recall: ${allChannels[idx].name}", Toast.LENGTH_SHORT).show()
                switchChannel(idx, immediatePlayback = true)
            }
        } else {
            Toast.makeText(this, "No previous channel yet", Toast.LENGTH_SHORT).show()
        }
    }

    // =========================================================================
    // 4D CRYSTAL GLASS STUDIO MODAL DIALOG ENGINE (Replaces all plain AlertDialogs)
    // =========================================================================

    private fun build4dModalHeader(
        iconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String
    ): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_header_4d)
            setPadding(dp(14), dp(12), dp(14), dp(12))

            val iconFrame = ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
            }
            addView(iconFrame)

            val textCol = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(12)
                    marginEnd = dp(8)
                }
            }
            val tvTitle = TextView(this@PlayerActivity).apply {
                text = title
                textSize = 15.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#F8FAFC"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvSub = TextView(this@PlayerActivity).apply {
                text = subtitle
                textSize = 11.5f
                setTextColor(Color.parseColor("#BAE6FD"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvTitle)
            textCol.addView(tvSub)
            addView(textCol)

            if (badgeText.isNotBlank()) {
                val tvBadge = TextView(this@PlayerActivity).apply {
                    text = badgeText
                    textSize = 10.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#38BDF8"))
                    setBackgroundResource(R.drawable.bg_badge_neon)
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                }
                addView(tvBadge)
            }
        }
    }

    private fun create4dActionCapsuleButton(
        label: String,
        bgRes: Int,
        iconRes: Int = 0,
        onClick: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundResource(bgRes)
            backgroundTintList = null
            isFocusable = true
            setPadding(dp(16), dp(8), dp(16), dp(8))
            if (iconRes != 0) {
                setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0)
                compoundDrawablePadding = dp(7)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(40)
            ).apply {
                marginStart = dp(8)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun present4dGlassDialog(rootCard: View, widthDp: Int = 540): AlertDialog {
        val dlg = AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
            .setView(rootCard)
            .create()
        dlg.show()
        dlg.window?.let { win ->
            win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val maxW = (resources.displayMetrics.widthPixels * 0.90f).toInt()
            val targetW = dp(widthDp).coerceAtMost(maxW)
            win.setLayout(targetW, WindowManager.LayoutParams.WRAP_CONTENT)
        }
        return dlg
    }

    private fun show4dGlassListModal(
        headerIconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String,
        options: List<GlassModalOption>,
        closeLabel: String = "Close"
    ) {
        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(build4dModalHeader(headerIconRes, title, subtitle, badgeText))

        val maxScrollHeight = (resources.displayMetrics.heightPixels * 0.56f).toInt().coerceAtLeast(dp(180))
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
                bottomMargin = dp(10)
            }
        }
        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        var firstFocusableRow: View? = null
        options.forEachIndexed { idx, opt ->
            val rowCard = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(
                    if (opt.isHighlighted) themes[currentThemeIndex].activeRowDrawableRes
                    else R.drawable.bg_dialog_item_4d
                )
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx < options.lastIndex) bottomMargin = dp(7)
                }
                setOnClickListener {
                    dialogRef?.dismiss()
                    opt.onClick()
                }
            }

            val iconView = ImageView(this).apply {
                setImageResource(opt.iconRes)
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(6), dp(6), dp(6), dp(6))
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
            }
            rowCard.addView(iconView)

            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(11)
                    marginEnd = dp(8)
                }
            }
            val tvRowTitle = TextView(this).apply {
                text = opt.title
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvRowSub = TextView(this).apply {
                text = opt.subtitle
                textSize = 11f
                setTextColor(if (opt.isHighlighted) Color.parseColor("#FEF08A") else Color.parseColor("#94A3B8"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvRowTitle)
            textCol.addView(tvRowSub)
            rowCard.addView(textCol)

            if (opt.badgeText.isNotBlank()) {
                val badge = TextView(this).apply {
                    text = opt.badgeText
                    textSize = 10.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (opt.isHighlighted) Color.parseColor("#6EE7B7") else Color.parseColor("#38BDF8"))
                    setBackgroundResource(
                        if (opt.isHighlighted) R.drawable.bg_live_dot_pill else R.drawable.bg_badge_neon
                    )
                    setPadding(dp(9), dp(4), dp(9), dp(4))
                }
                rowCard.addView(badge)
            }

            if (firstFocusableRow == null || opt.isHighlighted) {
                firstFocusableRow = rowCard
            }
            listContainer.addView(rowCard)
        }

        scroll.addView(listContainer)
        rootCard.addView(scroll)

        scroll.post {
            if (scroll.height > maxScrollHeight) {
                scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply {
                    height = maxScrollHeight
                }
            }
        }

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        footer.addView(
            create4dActionCapsuleButton(closeLabel, R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 560)
        firstFocusableRow?.post { firstFocusableRow?.requestFocus() }
    }

    private fun show4dGlassFormModal(
        headerIconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String,
        fields: List<GlassFormFieldSpec>,
        neutralLabel: String? = null,
        neutralBgRes: Int = R.drawable.bg_btn_3d_emerald,
        neutralIconRes: Int = 0,
        onNeutral: (() -> Unit)? = null,
        positiveLabel: String,
        positiveBgRes: Int = R.drawable.bg_btn_3d_cyan,
        positiveIconRes: Int = 0,
        onSubmit: (List<String>) -> Unit
    ) {
        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(build4dModalHeader(headerIconRes, title, subtitle, badgeText))

        val formBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
                bottomMargin = dp(14)
            }
        }

        val editTexts = ArrayList<EditText>(fields.size)
        fields.forEachIndexed { idx, spec ->
            val lbl = TextView(this).apply {
                text = spec.label
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#7DD3FC"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx > 0) topMargin = dp(8)
                    bottomMargin = dp(4)
                }
            }
            formBox.addView(lbl)

            val et = EditText(this).apply {
                hint = spec.hint
                setText(spec.initialValue)
                setSingleLine(true)
                inputType = spec.inputType
                textSize = 13f
                setTextColor(Color.WHITE)
                setHintTextColor(Color.parseColor("#94A3B8"))
                setBackgroundResource(R.drawable.bg_glass_input_4d)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setCompoundDrawablesWithIntrinsicBounds(spec.iconRes, 0, 0, 0)
                compoundDrawablePadding = dp(10)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(44)
                )
            }
            editTexts.add(et)
            formBox.addView(et)
        }
        rootCard.addView(formBox)

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        if (!neutralLabel.isNullOrBlank() && onNeutral != null) {
            val neutralBtn = create4dActionCapsuleButton(neutralLabel, neutralBgRes, neutralIconRes) {
                dialogRef?.dismiss()
                onNeutral()
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).marginStart = 0
            }
            footer.addView(neutralBtn)
        }

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        footer.addView(spacer)

        footer.addView(
            create4dActionCapsuleButton("Cancel", R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        footer.addView(
            create4dActionCapsuleButton(positiveLabel, positiveBgRes, positiveIconRes) {
                val values = editTexts.map { it.text?.toString()?.trim().orEmpty() }
                dialogRef?.dismiss()
                onSubmit(values)
            }
        )
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 540)
        editTexts.firstOrNull()?.post { editTexts.firstOrNull()?.requestFocus() }
    }

    private fun showAudioAndQualityDialog() {
        val player = exoPlayer ?: return
        val options = ArrayList<GlassModalOption>(12)

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_speed_bolt,
                title = "Sync to Live Broadcast Edge",
                subtitle = "Jump directly to real-time live edge with zero delay",
                badgeText = "ZERO DELAY",
                isHighlighted = false
            ) {
                player.seekToDefaultPosition()
                player.prepare()
                player.playWhenReady = true
                Toast.makeText(this, "⚡ Synced to real-time live edge!", Toast.LENGTH_SHORT).show()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "Buffer Profile: ${activeBufferProfile.label}",
                subtitle = activeBufferProfile.subtitle,
                badgeText = "CHANGE",
                isHighlighted = false
            ) {
                showBufferProfileDialog()
            }
        )

        val qualities = listOf(
            Triple("Video Quality: Auto", "Smart 1080p / 8 Mbps Low-RAM Hardware Guard", null as Pair<Int, Int>?),
            Triple("Video Quality: 1080p Full HD", "1920x1080 • Maximum Crystal Sharpness", 1920 to 1080),
            Triple("Video Quality: 720p HD", "1280x720 • Recommended for 512MB RAM Smart TVs", 1280 to 720),
            Triple("Video Quality: 480p SD", "854x480 • Fast Zap & Mobile Data Saver", 854 to 480),
            Triple("Video Quality: 360p Eco", "640x360 • Ultra Low Bandwidth Mode", 640 to 360)
        )
        for ((titleText, subText, size) in qualities) {
            val tagKey = if (size == null) "Auto" else "${size.second}p"
            val isCurrent = selectedQualityLabel == tagKey
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_video_4k,
                    title = titleText,
                    subtitle = subText,
                    badgeText = if (isCurrent) "ACTIVE ✓" else tagKey.uppercase(Locale.ROOT),
                    isHighlighted = isCurrent
                ) {
                    val builder = player.trackSelectionParameters.buildUpon()
                    if (size == null) {
                        if (isLowRamTvDevice) {
                            builder.setMaxVideoSize(1920, 1080).setMaxVideoBitrate(8_000_000)
                        } else {
                            builder.clearVideoSizeConstraints()
                        }
                        selectedQualityLabel = "Auto"
                    } else {
                        builder.setMaxVideoSize(size.first, size.second)
                        selectedQualityLabel = "${size.second}p"
                    }
                    player.trackSelectionParameters = builder.build()
                    Toast.makeText(this, "Video Quality set to $selectedQualityLabel", Toast.LENGTH_SHORT).show()
                }
            )
        }

        val tracks: Tracks = player.currentTracks
        var audioIndex = 1
        val currentChId = allChannels.getOrNull(currentChannelIndex)?.id
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO && group.isSupported) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val rawLang = format.language
                    val lang = rawLang?.let { Locale(it).displayLanguage }?.ifBlank { null } ?: "Track $audioIndex"
                    val label = format.label?.takeIf { it.isNotBlank() } ?: "Broadcast Audio"
                    val chCount = if (format.channelCount > 0) "${format.channelCount}ch" else "Stereo"
                    val isSelected = group.isTrackSelected(i)
                    val trackGroup = group.mediaTrackGroup
                    val trackIdx = i
                    options.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_audio_hd,
                            title = "Audio Track $audioIndex: $lang",
                            subtitle = "$label • $chCount • Auto-saved for this channel",
                            badgeText = if (isSelected) "PLAYING ✓" else chCount.uppercase(Locale.ROOT),
                            isHighlighted = isSelected
                        ) {
                            player.trackSelectionParameters = player.trackSelectionParameters
                                .buildUpon()
                                .setOverrideForType(TrackSelectionOverride(trackGroup, trackIdx))
                                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                .build()
                            if (!currentChId.isNullOrBlank() && !rawLang.isNullOrBlank()) {
                                profileStore.setPreferredAudioLanguage(currentChId, rawLang)
                            }
                            Toast.makeText(this, "Switched to $lang $label (Saved for channel)", Toast.LENGTH_SHORT).show()
                        }
                    )
                    audioIndex++
                }
            }
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "Subtitles / Closed Captions",
                subtitle = "Toggle DVB / CEA-608 / WebVTT live broadcast subtitles",
                badgeText = if (subtitlesEnabled) "ON ✓" else "OFF",
                isHighlighted = subtitlesEnabled
            ) {
                subtitlesEnabled = !subtitlesEnabled
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
                    .build()
                Toast.makeText(
                    this,
                    if (subtitlesEnabled) "Subtitles Enabled" else "Subtitles Disabled",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_audio_hd,
            title = "Audio, Video Quality & Buffer Profiles",
            subtitle = "Real-Time Media3 Track Engine • ${liveResolutionLabel}${if (liveTelemetryDetail.isNotEmpty()) " • $liveTelemetryDetail" else ""}",
            badgeText = selectedQualityLabel.uppercase(Locale.ROOT),
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showBufferProfileDialog() {
        val options = BufferProfile.values().map { p ->
            val isCur = p == activeBufferProfile
            GlassModalOption(
                iconRes = if (p == BufferProfile.LOW_LATENCY || p == BufferProfile.ULTRA_FAST_ZAP) {
                    R.drawable.ic_3d_speed_bolt
                } else {
                    R.drawable.ic_3d_ram_gauge
                },
                title = p.label,
                subtitle = p.subtitle,
                badgeText = if (isCur) "ACTIVE ✓" else "${p.playBufferMs}ms",
                isHighlighted = isCur
            ) {
                if (p != activeBufferProfile) {
                    activeBufferProfile = p
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("buffer_profile_id", p.id)
                        .apply()
                    initializeMedia3ProEngine(recreateIfPresent = true)
                    Toast.makeText(this, "Buffer Profile: ${p.label}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_ram_gauge,
            title = "Adaptive Buffer Profiles (512MB Tuned)",
            subtitle = "Choose start speed vs. network cushion for your Smart TV",
            badgeText = "512MB GUARD",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showThemeAndPipDialog() {
        val options = ArrayList<GlassModalOption>(12)
        themes.forEachIndexed { idx, t ->
            val isCur = idx == currentThemeIndex
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_theme,
                    title = "4D Theme: ${t.name}",
                    subtitle = t.subtitle,
                    badgeText = if (isCur) "ACTIVE ✓" else "APPLY",
                    isHighlighted = isCur
                ) {
                    applyTheme(idx)
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putInt("theme_index", idx)
                        .apply()
                    Toast.makeText(this, "4D Theme applied: ${t.name}", Toast.LENGTH_SHORT).show()
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Auto-Start on TV Boot",
                subtitle = "Launch StreamX automatically when Android TV powers on",
                badgeText = if (autoBootEnabled) "ON ✓" else "OFF",
                isHighlighted = autoBootEnabled
            ) {
                toggleAutoBootSetting()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "Auto-Resume Last Watched Channel",
                subtitle = "Instantly tune to your last channel on app startup",
                badgeText = if (autoResumeEnabled) "ON ✓" else "OFF",
                isHighlighted = autoResumeEnabled
            ) {
                toggleAutoResumeSetting()
            }
        )

        val hasPin = profileStore.hasParentalPin()
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "4-Digit Parental PIN Lock",
                subtitle = "Protect specific channel categories with a 4-digit PIN",
                badgeText = if (hasPin) "LOCKED ✓" else "OFF",
                isHighlighted = hasPin
            ) {
                showParentalPinSettingsDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "512MB RAM & Zap Telemetry Monitor",
                subtitle = "Inspect real-time JVM/Native heap, switch latency & cache size",
                badgeText = "LIVE STATS"
            ) {
                showPerformanceMonitorDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_pip,
                title = "Enter Picture-in-Picture (PiP Mini Player)",
                subtitle = "Continue watching live TV in a floating corner window",
                badgeText = "MINI TV"
            ) {
                enterPipModeSafe()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Clear Offline SXB2 Channel & EPG Cache",
                subtitle = "Purge cached playlists and free flash/RAM memory",
                badgeText = "CLEAN"
            ) {
                lifecycleScope.launch {
                    channelCache.clearAllCaches()
                    epgCache.clear()
                    StreamPreFetcher.trimIdleCacheOnLowMemory()
                    Toast.makeText(
                        this@PlayerActivity,
                        "Caches cleared! Tap Sync to reload.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_theme,
            title = "4D Studio Themes, Parental Lock & Diagnostics",
            subtitle = "Customize crystal glass themes, boot behavior & 512MB telemetry",
            badgeText = "4D STUDIO",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showParentalPinSettingsDialog() {
        val currentPin = profileStore.getParentalPin()
        val currentCat = allChannels.getOrNull(currentChannelIndex)?.category ?: "General"
        val isCatLocked = profileStore.getLockedCategories().any { it.equals(currentCat, ignoreCase = true) }

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = if (currentPin.length == 4) "Change 4-Digit Parental PIN" else "Set 4-Digit Parental PIN",
                subtitle = "Create or update your 4-digit category security code",
                badgeText = if (currentPin.length == 4) "ACTIVE ✓" else "SET PIN",
                isHighlighted = currentPin.length == 4
            ) {
                show4dGlassFormModal(
                    headerIconRes = R.drawable.ic_3d_lock,
                    title = "Set 4-Digit Parental PIN",
                    subtitle = "Enter exactly 4 numeric digits to lock restricted categories",
                    badgeText = "SECURITY",
                    fields = listOf(
                        GlassFormFieldSpec(
                            label = "4-DIGIT PARENTAL PIN CODE",
                            hint = "Enter 4-digit PIN (e.g. 1234)",
                            iconRes = R.drawable.ic_3d_lock,
                            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                        )
                    ),
                    positiveLabel = "Save PIN",
                    positiveBgRes = R.drawable.bg_btn_3d_gold,
                    positiveIconRes = R.drawable.ic_3d_lock
                ) { values ->
                    val pin = values.firstOrNull().orEmpty()
                    if (pin.length == 4 && pin.all { it.isDigit() }) {
                        profileStore.setParentalPin(pin)
                        unlockedSessionCategories.clear()
                        Toast.makeText(this, "🔒 4-Digit Parental PIN Enabled!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Please enter exactly 4 digits", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_category,
                title = "Lock / Unlock Category: $currentCat",
                subtitle = "Toggle PIN protection for the currently playing channel's group",
                badgeText = if (isCatLocked) "LOCKED 🔒" else "UNLOCKED",
                isHighlighted = isCatLocked
            ) {
                val locked = profileStore.toggleCategoryLock(currentCat)
                Toast.makeText(
                    this,
                    if (locked) "🔒 Category '$currentCat' Locked" else "🔓 Category '$currentCat' Unlocked",
                    Toast.LENGTH_SHORT
                ).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Disable Parental PIN Lock",
                subtitle = "Remove PIN requirement across all channel categories",
                badgeText = "DISABLE"
            ) {
                profileStore.setParentalPin("")
                unlockedSessionCategories.clear()
                Toast.makeText(this, "🔓 Parental PIN Lock Disabled", Toast.LENGTH_SHORT).show()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "4-Digit Parental PIN Lock",
            subtitle = "Category access control for family-safe television viewing",
            badgeText = if (currentPin.length == 4) "PIN ON" else "PIN OFF",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun promptParentalPinToUnlock(category: String, onUnlocked: () -> Unit) {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "Locked Category: $category",
            subtitle = "Enter your 4-digit Parental PIN to watch channels in '$category'",
            badgeText = "LOCKED 🔒",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "ENTER 4-DIGIT PARENTAL PIN",
                    hint = "••••",
                    iconRes = R.drawable.ic_3d_lock,
                    inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Unlock Category",
            positiveBgRes = R.drawable.bg_btn_3d_gold,
            positiveIconRes = R.drawable.ic_3d_lock
        ) { values ->
            if (profileStore.verifyParentalPin(values.firstOrNull().orEmpty())) {
                unlockedSessionCategories.add(category.lowercase(Locale.ROOT))
                onUnlocked()
            } else {
                Toast.makeText(this, "❌ Incorrect Parental PIN", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleAutoBootSetting() {
        autoBootEnabled = !autoBootEnabled
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("auto_boot_enabled", autoBootEnabled)
            .apply()
        runCatching {
            val comp = ComponentName(this, BootReceiver::class.java)
            val newState = if (autoBootEnabled) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            }
            packageManager.setComponentEnabledSetting(comp, newState, PackageManager.DONT_KILL_APP)
        }
        Toast.makeText(
            this,
            "🚀 Auto-Start on TV Boot: ${if (autoBootEnabled) "ENABLED" else "DISABLED"}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun toggleAutoResumeSetting() {
        autoResumeEnabled = !autoResumeEnabled
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("auto_resume_enabled", autoResumeEnabled)
            .apply()
        Toast.makeText(
            this,
            "▶️ Auto-Resume Last Channel: ${if (autoResumeEnabled) "ENABLED" else "DISABLED"}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showPerformanceMonitorDialog() {
        val rt = Runtime.getRuntime()
        val usedHeapMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val maxHeapMb = (rt.maxMemory() / (1024 * 1024)).coerceAtLeast(1)
        val heapPct = ((usedHeapMb * 100L) / maxHeapMb).toInt().coerceIn(5, 100)
        val nativeHeapMb = Debug.getNativeHeapAllocatedSize() / (1024 * 1024)
        val chCacheKb = channelCache.totalCacheSizeBytes() / 1024
        val epgCacheKb = epgCache.cacheSizeBytes() / 1024

        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(
            build4dModalHeader(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "StreamX v14.0 Hyper-Glass 512MB Monitor",
                subtitle = "Real-Time Memory Footprint, Direct-RAM Engine & Zap Latency",
                badgeText = "${usedHeapMb}/${maxHeapMb} MB"
            )
        )

        val gaugeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_item_4d)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(10)
            }
        }
        val tvGaugeLabel = TextView(this).apply {
            text = "JVM Heap Memory Pressure: $usedHeapMb MB used of $maxHeapMb MB ($heapPct%) • Native: $nativeHeapMb MB"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#E0F2FE"))
        }
        val heapBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = heapPct
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(8)
            ).apply {
                topMargin = dp(6)
            }
        }
        gaugeBox.addView(tvGaugeLabel)
        gaugeBox.addView(heapBar)
        rootCard.addView(gaugeBox)

        val metrics = listOf(
            "Device RAM Profile" to "${totalDeviceRamMb} MB (${if (isLowRamTvDevice) "512MB Low-RAM Guard" else "Standard Mode"})",
            "Active Buffer Profile" to activeBufferProfile.label,
            "Stream Engine Path" to "Direct-RAM OkHttp + PreloadAware HLS",
            "Smart Preload Engine" to StreamPreFetcher.preloadStatusSummary(),
            "Last Channel Zap Latency" to if (lastChannelSwitchMs > 0) "${lastChannelSwitchMs} ms" else "Instant Ready",
            "Last Playlist Load Time" to "${lastPlaylistLoadDurationMs} ms (SXB2 Line-Binary)",
            "Loaded Channels & Cache" to "${allChannels.size} Channels • ${chCacheKb} KB SXB2 • ${epgCacheKb} KB EPG"
        )

        val metricsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
                bottomMargin = dp(12)
            }
        }
        for ((k, v) in metrics) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_dialog_item_4d)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(5)
                }
            }
            val tvK = TextView(this).apply {
                text = k
                textSize = 11.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#7DD3FC"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.42f)
            }
            val tvV = TextView(this).apply {
                text = v
                textSize = 11.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.58f)
            }
            row.addView(tvK)
            row.addView(tvV)
            metricsContainer.addView(row)
        }
        rootCard.addView(metricsContainer)

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        val trimBtn = create4dActionCapsuleButton("Trim RAM Now", R.drawable.bg_btn_3d_emerald, R.drawable.ic_3d_speed_bolt) {
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            sharedAllocator?.trim()
            runCatching { Glide.get(this).clearMemory() }
            dialogRef?.dismiss()
            Toast.makeText(this, "⚡ RAM trimmed & idle buffers freed!", Toast.LENGTH_SHORT).show()
        }
        val closeBtn = create4dActionCapsuleButton("Close", R.drawable.bg_btn_3d_slate) {
            dialogRef?.dismiss()
        }
        footer.addView(trimBtn)
        footer.addView(closeBtn)
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 560)
        trimBtn.post { trimBtn.requestFocus() }
    }

    private fun applyTheme(index: Int) {
        currentThemeIndex = index.coerceIn(themes.indices)
        val palette = themes[currentThemeIndex]
        val badgeTextColor = Color.parseColor(palette.badgeTextHex)
        val statusColor = Color.parseColor(palette.statusHex)

        tvChannelNumber.setTextColor(badgeTextColor)
        tvChannelCategory.setTextColor(statusColor)
        updateTabButton3dSelection(activeTab)
        channelAdapter.setActiveRowDrawable(palette.activeRowDrawableRes)
    }

    private fun enterPipModeSafe() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                Log.w("StreamX", "PiP not supported: ${e.message}")
                Toast.makeText(this, "PiP not supported on this device", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "PiP requires Android 8.0+", Toast.LENGTH_SHORT).show()
        }
    }

    private fun forceRefreshActivePlaylist() {
        val creds = activeXtreamCreds
        when {
            activeSourceType == ProfileType.XTREAM && creds != null -> {
                Toast.makeText(this, "🔄 Syncing fresh channels from Xtream Server...", Toast.LENGTH_SHORT).show()
                loadXtreamChannels(creds, forceNetworkRefresh = true)
            }
            activeSourceType == ProfileType.M3U && activeM3uInput.isNotBlank() -> {
                Toast.makeText(this, "🔄 Syncing fresh M3U playlist...", Toast.LENGTH_SHORT).show()
                loadM3uFromInput(activeM3uInput, activeM3uLabel, forceNetworkRefresh = true)
            }
            else -> {
                Toast.makeText(this, "Connect an Xtream or M3U account first to sync", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleCurrentChannelFavorite() {
        if (allChannels.isEmpty()) return
        val ch = allChannels[currentChannelIndex]
        if (favoriteIds.contains(ch.id)) {
            favoriteIds.remove(ch.id)
            Toast.makeText(this, "Removed from ★ Favorites", Toast.LENGTH_SHORT).show()
        } else {
            favoriteIds.add(ch.id)
            Toast.makeText(this, "Added to ★ Favorites!", Toast.LENGTH_SHORT).show()
        }
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putStringSet("fav_ids", HashSet(favoriteIds))
            .apply()
        updateFavButtonUi(ch.id)
        if (leftChannelDrawer.visibility == View.VISIBLE) {
            if (activeTab == "FAV") {
                renderDrawerList()
            } else {
                channelAdapter.notifyFavoriteChanged(currentChannelIndex)
            }
        }
    }

    private fun updateFavButtonUi(channelId: String) {
        val isFav = favoriteIds.contains(channelId)
        btnToggleFavorite.text = if (isFav) "★" else "☆"
    }

    private fun renderDrawerList(
        debounceMs: Long = 0L,
        scrollToActive: Boolean = false,
        requestFocusOnActive: Boolean = false
    ) {
        filterJob?.cancel()
        filterJob = lifecycleScope.launch {
            if (debounceMs > 0L) {
                delay(debounceMs)
            }
            val snapshotChannels = allChannels
            val snapshotSeq = allSequentialIndices
            val snapshotByCategory = channelsByCategory
            val snapshotFavs = HashSet(favoriteIds)
            val snapshotRecents = ArrayList(recentIds)
            val snapshotById = channelIndexById
            val tab = activeTab
            val query = searchQuery.trim()
            val category = selectedCategory
            val activeIdx = currentChannelIndex
            val oldIndices = channelAdapter.currentIndices()

            val (filteredAll, pagedSlice, diffResult) = withContext(Dispatchers.Default) {
                val matchAllCat = category == "All categories" || category.isBlank()
                val baseIndices: IntArray = when (tab) {
                    "FAV" -> {
                        val temp = ArrayList<Int>(snapshotFavs.size)
                        for (i in snapshotChannels.indices) {
                            if (snapshotFavs.contains(snapshotChannels[i].id)) temp.add(i)
                        }
                        temp.toIntArray()
                    }
                    "RECENT" -> {
                        val temp = ArrayList<Int>(snapshotRecents.size)
                        for (id in snapshotRecents) {
                            val idx = snapshotById[id]
                            if (idx != null && idx in snapshotChannels.indices) temp.add(idx)
                        }
                        temp.toIntArray()
                    }
                    else -> {
                        if (matchAllCat) {
                            snapshotSeq
                        } else {
                            snapshotByCategory[category.lowercase(Locale.ROOT)] ?: IntArray(0)
                        }
                    }
                }

                val resultIndices: IntArray = if (query.isEmpty() && (tab == "ALL" || matchAllCat)) {
                    baseIndices
                } else {
                    val temp = ArrayList<Int>(256)
                    for (idx in baseIndices) {
                        if (idx !in snapshotChannels.indices) continue
                        val ch = snapshotChannels[idx]
                        val catMatches = (tab == "ALL") || matchAllCat || ch.category.equals(category, ignoreCase = true)
                        val queryMatches = query.isEmpty() ||
                            ch.name.contains(query, ignoreCase = true) ||
                            ch.category.contains(query, ignoreCase = true)
                        if (catMatches && queryMatches) {
                            temp.add(idx)
                        }
                    }
                    temp.toIntArray()
                }

                val activePosInResult = if (scrollToActive) {
                    resultIndices.indexOfFirst { it == activeIdx }
                } else {
                    0
                }
                val requiredWindow = ((activePosInResult + 200).coerceAtLeast(pageStepSize))
                    .coerceAtMost(resultIndices.size)
                val slice = if (resultIndices.size > requiredWindow) {
                    resultIndices.copyOfRange(0, requiredWindow)
                } else {
                    resultIndices
                }

                val diff = if (oldIndices.isNotEmpty() && slice.isNotEmpty() &&
                    oldIndices.size <= 1800 && slice.size <= 1800 && oldIndices !== slice
                ) {
                    DiffUtil.calculateDiff(object : DiffUtil.Callback() {
                        override fun getOldListSize(): Int = oldIndices.size
                        override fun getNewListSize(): Int = slice.size
                        override fun areItemsTheSame(oldPos: Int, newPos: Int): Boolean =
                            oldIndices[oldPos] == slice[newPos]
                        override fun areContentsTheSame(oldPos: Int, newPos: Int): Boolean =
                            oldIndices[oldPos] == slice[newPos]
                    }, false)
                } else {
                    null
                }
                Triple(resultIndices, slice, diff)
            }

            fullFilteredIndices = filteredAll
            currentPagedLimit = pagedSlice.size

            if (pagedSlice.isEmpty()) {
                tvEmptyDrawer.text = if (tab == "FAV") {
                    "★ कोई Favorite चैनल नहीं है। ☆ बटन दबाकर जोड़ें।"
                } else {
                    "कोई चैनल नहीं मिला।"
                }
                tvEmptyDrawer.visibility = View.VISIBLE
                channelListRecycler.visibility = View.GONE
                channelAdapter.submitIndices(IntArray(0), activeIdx, null)
            } else {
                tvEmptyDrawer.visibility = View.GONE
                channelListRecycler.visibility = View.VISIBLE
                channelAdapter.submitIndices(pagedSlice, activeIdx, diffResult, isAscending = (tab != "RECENT"))
                if (scrollToActive) {
                    val pos = pagedSlice.indexOfFirst { it == activeIdx }.coerceAtLeast(0)
                    val lm = channelListRecycler.layoutManager as? LinearLayoutManager
                    lm?.scrollToPositionWithOffset(pos, 120)
                    if (requestFocusOnActive) {
                        channelListRecycler.post {
                            val holder = channelListRecycler.findViewHolderForAdapterPosition(pos)
                            if (holder != null) {
                                holder.itemView.requestFocus()
                            } else {
                                channelListRecycler.requestFocus()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun importLocalM3uUri(uri: Uri) {
        loadChannelsJob?.cancel()
        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            tvActiveSectionBadge.text = "⏳ Importing playlist..."
            runCatching {
                withContext(Dispatchers.IO) {
                    val cachedFile = File(filesDir, "local_playlist_${System.currentTimeMillis()}.m3u")
                    contentResolver.openInputStream(uri)?.use { input ->
                        cachedFile.outputStream().use { output ->
                            input.copyTo(output, bufferSize = 65536)
                        }
                    } ?: error("Cannot read selected file")
                    val channels = cachedFile.bufferedReader(Charsets.UTF_8).use { reader ->
                        M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                    }
                    cachedFile to channels
                }
            }.onSuccess { (cachedFile, channels) ->
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (channels.isNotEmpty()) {
                    val fileSource = "file://${cachedFile.absolutePath}"
                    val localProfile = PlaylistProfile(
                        name = "Local playlist (${channels.size} ch)",
                        type = ProfileType.M3U,
                        source = fileSource
                    )
                    profileStore.save(localProfile)
                    profileStore.setActive(localProfile.id)
                    activeSourceType = ProfileType.M3U
                    activeM3uInput = fileSource
                    activeM3uLabel = localProfile.name
                    val cKey = cacheKeyFor("m3u_$fileSource")
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, channels, maxLimit = maxPlaylistLimit)
                    }
                    applyLoadedChannels(channels, "StreamX Pro • ${localProfile.name}", resumeLastWatched = false)
                    Toast.makeText(this@PlayerActivity, "Imported & cached ${channels.size} channels", Toast.LENGTH_LONG).show()
                } else {
                    tvActiveSectionBadge.text = "StreamX Pro • All Live TV"
                    Toast.makeText(this@PlayerActivity, "No valid M3U channels found", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                Log.w("StreamX", "Local M3U import failed", e)
                tvActiveSectionBadge.text = "StreamX Pro • All Live TV"
                Toast.makeText(this@PlayerActivity, "File import failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showEpgUrlDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_epg,
            title = "Load XMLTV EPG Program Guide",
            subtitle = "Parsed Now/Next TV schedules are cached locally and refreshed automatically",
            badgeText = "XMLTV EPG",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "XMLTV EPG GUIDE URL (.XML)",
                    hint = "https://example.com/epg.xml",
                    iconRes = R.drawable.ic_3d_epg,
                    initialValue = prefs.getString("last_epg_url", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            positiveLabel = "Load & Cache Guide",
            positiveBgRes = R.drawable.bg_btn_3d_teal,
            positiveIconRes = R.drawable.ic_3d_sync
        ) { values ->
            val url = values.firstOrNull().orEmpty()
            if (url.isNotBlank()) {
                prefs.edit().putString("last_epg_url", url).apply()
                loadXmltvEpg(url, silentBackground = false)
            }
        }
    }

    private fun loadXmltvEpg(url: String, silentBackground: Boolean = false) {
        epgLoadJob?.cancel()
        epgLoadJob = lifecycleScope.launch {
            if (!silentBackground) {
                Toast.makeText(this@PlayerActivity, "Loading EPG in background...", Toast.LENGTH_SHORT).show()
            }
            val filterIds = knownEpgAndChannelIds.takeIf { it.isNotEmpty() }
            runCatching {
                withContext(Dispatchers.IO) {
                    val request = Request.Builder().url(url).build()
                    NetworkClient.apiClient.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) error("EPG HTTP ${response.code}")
                        val body = response.body ?: error("Empty EPG response")
                        BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 32768).use { reader ->
                            XmltvParser.parseNowNext(
                                reader = reader,
                                relevantChannelIds = filterIds,
                                shouldCancel = { !isActive }
                            )
                        }
                    }
                }
            }.onSuccess { parsedEpg ->
                if (parsedEpg.isNotEmpty()) {
                    epgMap = parsedEpg
                    launch(Dispatchers.IO) {
                        epgCache.saveEpg(url, parsedEpg)
                    }
                    if (allChannels.isNotEmpty()) updateOsdForCurrentChannel()
                }
                if (!silentBackground) {
                    Toast.makeText(this@PlayerActivity, "EPG cached: ${epgMap.size} channel entries", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                Log.w("StreamX", "EPG load error", e)
                if (!silentBackground) {
                    Toast.makeText(this@PlayerActivity, "EPG error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showProfilesDialog() {
        val profiles = profileStore.all()
        val activeId = profileStore.activeId()
        val options = ArrayList<GlassModalOption>(profiles.size + 6)

        profiles.forEach { p ->
            val isAct = p.id == activeId
            options.add(
                GlassModalOption(
                    iconRes = if (p.type == ProfileType.XTREAM) R.drawable.ic_3d_xtream else R.drawable.ic_3d_playlist,
                    title = p.name,
                    subtitle = "${p.type} Account • ${redactUrlForDisplay(p.source)}",
                    badgeText = if (isAct) "ACTIVE ✓" else "SWITCH",
                    isHighlighted = isAct
                ) {
                    activateProfile(p)
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_accounts,
                title = "Add New Playlist / IPTV Account",
                subtitle = "Save an M3U URL or Xtream Codes VIP account with AES-256 encryption",
                badgeText = "+ NEW"
            ) {
                showAddProfileDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "Force Sync Channels from Server",
                subtitle = "Refresh active playlist from network and update SXB2 cache",
                badgeText = "SYNC"
            ) {
                forceRefreshActivePlaylist()
            }
        )

        val hasPin = profileStore.hasParentalPin()
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "Parental PIN Lock Settings",
                subtitle = "Configure 4-digit PIN and lock specific categories",
                badgeText = if (hasPin) "LOCKED ✓" else "OFF",
                isHighlighted = hasPin
            ) {
                showParentalPinSettingsDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Auto-Start on TV Boot",
                subtitle = "Automatically launch StreamX when Android TV starts",
                badgeText = if (autoBootEnabled) "ON ✓" else "OFF",
                isHighlighted = autoBootEnabled
            ) {
                toggleAutoBootSetting()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "Auto-Resume Last Channel",
                subtitle = "Automatically play your last watched channel on launch",
                badgeText = if (autoResumeEnabled) "ON ✓" else "OFF",
                isHighlighted = autoResumeEnabled
            ) {
                toggleAutoResumeSetting()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Delete a Saved Account",
                subtitle = "Remove an existing M3U or Xtream profile from storage",
                badgeText = "REMOVE"
            ) {
                showDeleteProfileDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_accounts,
            title = "Saved Accounts, Playlists & Boot Settings",
            subtitle = "Multi-account manager with encrypted credentials & instant SXB2 cache",
            badgeText = "${profiles.size} SAVED",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showAddProfileDialog() {
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_playlist,
                title = "M3U / M3U8 Playlist Account",
                subtitle = "Add a remote M3U/M3U8 playlist link or raw #EXTM3U stream list",
                badgeText = "M3U8"
            ) {
                showSaveM3uProfileDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_xtream,
                title = "Xtream Codes VIP Account",
                subtitle = "Connect with Server URL, Username & Password via fast JSON stream API",
                badgeText = "VIP API",
                isHighlighted = true
            ) {
                showSaveXtreamProfileDialog()
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_accounts,
            title = "Choose IPTV Account Type",
            subtitle = "Select how you want to connect your live television channels",
            badgeText = "NEW PROFILE",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showSaveM3uProfileDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_playlist,
            title = "Save M3U / M3U8 Playlist Profile",
            subtitle = "Store playlist in SXB2 fast binary cache for instant startup",
            badgeText = "M3U PROFILE",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "PROFILE NAME",
                    hint = "Account name (e.g. Family Live TV)",
                    iconRes = R.drawable.ic_3d_accounts,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "M3U / M3U8 URL OR #EXTM3U TEXT",
                    hint = "https://server.com/playlist.m3u8",
                    iconRes = R.drawable.ic_3d_server,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            positiveLabel = "Save & Play",
            positiveBgRes = R.drawable.bg_btn_3d_emerald,
            positiveIconRes = R.drawable.ic_3d_playlist
        ) { values ->
            val name = values.getOrNull(0).orEmpty()
            val source = values.getOrNull(1).orEmpty()
            if (name.isBlank() || source.isBlank()) {
                Toast.makeText(this, "Name and playlist are required", Toast.LENGTH_LONG).show()
            } else {
                val p = PlaylistProfile(name = name, type = ProfileType.M3U, source = source)
                profileStore.save(p); profileStore.setActive(p.id); activateProfile(p)
            }
        }
    }

    private fun showSaveXtreamProfileDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_xtream,
            title = "Save Xtream Codes VIP Account",
            subtitle = "Credentials are encrypted with AES-256 and cached in SXB2 format",
            badgeText = "VIP XTREAM",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "ACCOUNT / PROFILE NAME",
                    hint = "Account name (e.g. Sports HD VIP)",
                    iconRes = R.drawable.ic_3d_accounts,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "XTREAM SERVER URL & PORT",
                    hint = "http://line.server.com:8080",
                    iconRes = R.drawable.ic_3d_server,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                ),
                GlassFormFieldSpec(
                    label = "USERNAME",
                    hint = "Enter Xtream Username",
                    iconRes = R.drawable.ic_3d_user,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "PASSWORD",
                    hint = "Enter Xtream Password",
                    iconRes = R.drawable.ic_3d_lock,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Save & Play",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_xtream
        ) { values ->
            val name = values.getOrNull(0).orEmpty()
            val server = values.getOrNull(1).orEmpty()
            val user = values.getOrNull(2).orEmpty()
            val pass = values.getOrNull(3).orEmpty()
            if (name.isBlank() || server.isBlank() || user.isBlank() || pass.isBlank()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_LONG).show()
            } else {
                val p = PlaylistProfile(
                    name = name,
                    type = ProfileType.XTREAM,
                    source = server,
                    username = user,
                    password = pass
                )
                profileStore.save(p); profileStore.setActive(p.id); activateProfile(p)
            }
        }
    }

    private fun showDeleteProfileDialog() {
        val profiles = profileStore.all()
        if (profiles.isEmpty()) {
            Toast.makeText(this, "No saved accounts", Toast.LENGTH_SHORT).show()
            return
        }
        val options = profiles.map { p ->
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Delete: ${p.name}",
                subtitle = "${p.type} • ${redactUrlForDisplay(p.source)}",
                badgeText = "DELETE"
            ) {
                profileStore.delete(p.id)
                if (profileStore.activeId() == p.id) {
                    val next = profileStore.all().firstOrNull()
                    if (next != null) {
                        profileStore.setActive(next.id)
                        activateProfile(next)
                    } else {
                        Toast.makeText(this, "Account deleted. Add a playlist to start.", Toast.LENGTH_LONG).show()
                    }
                }
                showProfilesDialog()
            }
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_trash,
            title = "Delete Saved Account",
            subtitle = "Select an account below to permanently remove it",
            badgeText = "${profiles.size} ACCOUNTS",
            options = options,
            closeLabel = "Cancel"
        )
    }

    private fun activateProfile(profile: PlaylistProfile) {
        profileStore.setActive(profile.id)
        tvActiveSectionBadge.text = "StreamX Pro • ${profile.name}"
        when (profile.type) {
            ProfileType.M3U -> loadM3uFromInput(profile.source, profile.name, forceNetworkRefresh = false)
            ProfileType.XTREAM -> loadXtreamChannels(
                XtreamCredentials(profile.name, profile.source, profile.username, profile.password),
                forceNetworkRefresh = false
            )
        }
    }

    private fun showXtreamLoginDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_xtream,
            title = "Xtream Codes VIP Login",
            subtitle = "High-Speed Live Stream API • Direct-RAM Zap & SXB2 Binary Cache",
            badgeText = "VIP HD",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "SERVER URL & PORT",
                    hint = "Server URL (e.g. http://line.server.com:8080)",
                    iconRes = R.drawable.ic_3d_server,
                    initialValue = prefs.getString("xtream_server", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                ),
                GlassFormFieldSpec(
                    label = "USERNAME",
                    hint = "Username",
                    iconRes = R.drawable.ic_3d_user,
                    initialValue = prefs.getString("xtream_user", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "PASSWORD",
                    hint = "Password",
                    iconRes = R.drawable.ic_3d_lock,
                    initialValue = prefs.getString("xtream_pass", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Connect & Play",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_xtream
        ) { values ->
            val srv = values.getOrNull(0).orEmpty()
            val usr = values.getOrNull(1).orEmpty()
            val pwd = values.getOrNull(2).orEmpty()
            if (srv.isNotEmpty() && usr.isNotEmpty()) {
                prefs.edit()
                    .putString("xtream_server", srv)
                    .putString("xtream_user", usr)
                    .putString("xtream_pass", pwd)
                    .apply()
                loadXtreamChannels(XtreamCredentials("TV", srv, usr, pwd), forceNetworkRefresh = true)
            }
        }
    }

    private fun loadXtreamChannels(creds: XtreamCredentials, forceNetworkRefresh: Boolean = false) {
        activeSourceType = ProfileType.XTREAM
        activeXtreamCreds = creds
        val cKey = cacheKeyFor("xtream_${creds.serverUrl.trim()}_${creds.username.trim()}")

        loadChannelsJob?.cancel()
        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()

            // 1. Fast SXB2 Cache Load + Progressive 80-Channel First Batch
            if (!forceNetworkRefresh) {
                updateBootStage(68, "Restoring Fast SXB2 Cache...", "Account: ${creds.profileName}")
                val cached = channelCache.loadChannels(cKey, maxLimit = maxPlaylistLimit) { firstBatch ->
                    withContext(Dispatchers.Main) {
                        if (currentPlayingStreamUrl.isEmpty()) {
                            applyLoadedChannels(
                                firstBatch,
                                "StreamX Pro • ⚡ ${creds.profileName} (${firstBatch.size}+ CH)",
                                resumeLastWatched = false,
                                isPreliminaryBatch = true
                            )
                        }
                    }
                }
                if (cached.isNotEmpty()) {
                    lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                    applyLoadedChannels(
                        cached,
                        "StreamX Pro • ⚡ ${creds.profileName} (${cached.size} CH)",
                        resumeLastWatched = true
                    )
                    if (isNetworkConnectedNow() && channelCache.isCacheStale(cKey)) {
                        scheduleSilentXtreamRefresh(creds, cKey)
                    }
                    return@launch
                }
            }

            // 2. Network Stream Load + 80-Channel Instant First Batch + Save SXB2 Cache
            updateBootStage(70, "Loading Playlist from Server...", "Connecting to ${creds.serverUrl}")
            tvActiveSectionBadge.text = "⏳ Loading Xtream..."
            val res = xtreamRepo.fetchLiveStreams(creds, maxStreams = maxPlaylistLimit) { firstBatch ->
                withContext(Dispatchers.Main) {
                    updateBootStage(76, "Loaded first ${firstBatch.size} channels...", "Playing immediately while streaming list")
                    applyLoadedChannels(
                        firstBatch,
                        "StreamX Pro • ⏳ ${creds.profileName} (${firstBatch.size}+ CH)",
                        resumeLastWatched = false,
                        isPreliminaryBatch = true
                    )
                }
            }
            res.onSuccess { list ->
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (list.isNotEmpty()) {
                    applyLoadedChannels(
                        list,
                        "StreamX Pro • ${creds.profileName} (${list.size} CH)",
                        resumeLastWatched = true
                    )
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, list, maxLimit = maxPlaylistLimit)
                    }
                    Toast.makeText(
                        this@PlayerActivity,
                        "Xtream Cached (${list.size} CH in SXB2 format)!",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    dismissDthBootOverlay("NO CHANNELS FOUND")
                    tvActiveSectionBadge.text = "StreamX Pro • No Channels"
                    Toast.makeText(this@PlayerActivity, "No live channels found on server", Toast.LENGTH_LONG).show()
                }
            }.onFailure { err ->
                Log.w("StreamX", "Xtream load error", err)
                val fallbackCached = channelCache.loadChannels(cKey, maxLimit = maxPlaylistLimit)
                if (fallbackCached.isNotEmpty()) {
                    applyLoadedChannels(
                        fallbackCached,
                        "StreamX Pro • ⚡ ${creds.profileName} (${fallbackCached.size} CH)",
                        resumeLastWatched = true
                    )
                } else {
                    dismissDthBootOverlay("CONNECTION ERROR")
                    tvActiveSectionBadge.text = "StreamX Pro • Connection Error"
                    Toast.makeText(this@PlayerActivity, "Xtream Error: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun scheduleSilentXtreamRefresh(creds: XtreamCredentials, cKey: String) {
        bgSyncJob?.cancel()
        bgSyncJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(4000L)
            val res = xtreamRepo.fetchLiveStreams(creds, maxStreams = maxPlaylistLimit)
            res.onSuccess { freshList ->
                if (freshList.isNotEmpty()) {
                    channelCache.saveChannels(cKey, freshList, maxLimit = maxPlaylistLimit)
                }
            }
        }
    }

    private fun showM3uLoadDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_playlist,
            title = "Load M3U / M3U8 Playlist",
            subtitle = "Stream from URL, paste raw #EXTM3U content, or pick a local .m3u/.m3u8 file",
            badgeText = "SXB2 CACHE",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "M3U / M3U8 PLAYLIST URL OR #EXTM3U CONTENT",
                    hint = "Paste M3U URL (https://.../playlist.m3u) or #EXTM3U",
                    iconRes = R.drawable.ic_3d_server,
                    initialValue = prefs.getString("m3u_url", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            neutralLabel = "Choose Local File",
            neutralBgRes = R.drawable.bg_btn_3d_emerald,
            neutralIconRes = R.drawable.ic_3d_playlist,
            onNeutral = {
                playlistPicker.launch(arrayOf("application/x-mpegURL", "audio/x-mpegurl", "text/plain", "*/*"))
            },
            positiveLabel = "Load Channels",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_sync
        ) { values ->
            val input = values.firstOrNull().orEmpty()
            if (input.isNotEmpty()) {
                prefs.edit().putString("m3u_url", input).apply()
                loadM3uFromInput(input, "M3U", forceNetworkRefresh = true)
            }
        }
    }

    private fun loadM3uFromInput(input: String, label: String = "M3U", forceNetworkRefresh: Boolean = false) {
        activeSourceType = ProfileType.M3U
        activeM3uInput = input
        activeM3uLabel = label
        val cKey = cacheKeyFor("m3u_${input.take(256)}")

        loadChannelsJob?.cancel()
        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            if (!forceNetworkRefresh) {
                updateBootStage(68, "Restoring Fast SXB2 Cache...", label)
                val cached = channelCache.loadChannels(cKey, maxLimit = maxPlaylistLimit) { firstBatch ->
                    withContext(Dispatchers.Main) {
                        if (currentPlayingStreamUrl.isEmpty()) {
                            applyLoadedChannels(
                                firstBatch,
                                "StreamX Pro • ⚡ $label (${firstBatch.size}+ CH)",
                                resumeLastWatched = false,
                                isPreliminaryBatch = true
                            )
                        }
                    }
                }
                if (cached.isNotEmpty()) {
                    lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                    applyLoadedChannels(
                        cached,
                        "StreamX Pro • ⚡ $label (${cached.size} CH)",
                        resumeLastWatched = true
                    )
                    if (isNetworkConnectedNow() &&
                        (input.startsWith("http://", true) || input.startsWith("https://", true)) &&
                        channelCache.isCacheStale(cKey)
                    ) {
                        scheduleSilentM3uRefresh(input, cKey)
                    }
                    return@launch
                }
            }

            updateBootStage(72, "Loading M3U Playlist...", label)
            tvActiveSectionBadge.text = "⏳ Loading M3U..."
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val emitFirstBatch: (List<Channel>) -> Unit = { batch ->
                        lifecycleScope.launch(Dispatchers.Main) {
                            if (currentPlayingStreamUrl.isEmpty()) {
                                applyLoadedChannels(
                                    batch,
                                    "StreamX Pro • ⏳ $label (${batch.size}+ CH)",
                                    resumeLastWatched = false,
                                    isPreliminaryBatch = true
                                )
                            }
                        }
                    }
                    when {
                        input.startsWith("http://", true) || input.startsWith("https://", true) -> {
                            NetworkClient.apiClient.newCall(Request.Builder().url(input).build()).execute().use { res ->
                                if (!res.isSuccessful) error("Playlist HTTP ${res.code}")
                                val body = res.body ?: error("Empty M3U response")
                                BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536).use { reader ->
                                    M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                                }
                            }
                        }
                        input.startsWith("file://", true) -> {
                            val file = File(Uri.parse(input).path ?: "")
                            if (!file.exists()) error("Saved playlist file not found")
                            file.bufferedReader(Charsets.UTF_8).use { reader ->
                                M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                            }
                        }
                        input.startsWith("content://", true) -> {
                            contentResolver.openInputStream(Uri.parse(input))?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                                M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                            } ?: emptyList()
                        }
                        else -> M3uParser.parse(input, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                    }
                }
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (parsed.isNotEmpty()) {
                    applyLoadedChannels(
                        parsed,
                        "StreamX Pro • $label (${parsed.size} CH)",
                        resumeLastWatched = true
                    )
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, parsed, maxLimit = maxPlaylistLimit)
                    }
                    Toast.makeText(this@PlayerActivity, "M3U Cached (${parsed.size} CH in SXB2 format)!", Toast.LENGTH_SHORT).show()
                } else {
                    dismissDthBootOverlay("NO CHANNELS FOUND")
                    tvActiveSectionBadge.text = "StreamX Pro • All Live TV"
                    Toast.makeText(this@PlayerActivity, "No valid channels found in M3U", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Log.w("StreamX", "M3U load error", e)
                val fallbackCached = channelCache.loadChannels(cKey, maxLimit = maxPlaylistLimit)
                if (fallbackCached.isNotEmpty()) {
                    applyLoadedChannels(
                        fallbackCached,
                        "StreamX Pro • ⚡ $label (${fallbackCached.size} CH)",
                        resumeLastWatched = true
                    )
                } else {
                    dismissDthBootOverlay("CONNECTION ERROR")
                    tvActiveSectionBadge.text = "StreamX Pro • M3U Error"
                    Toast.makeText(this@PlayerActivity, "M3U Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun scheduleSilentM3uRefresh(url: String, cKey: String) {
        bgSyncJob?.cancel()
        bgSyncJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(4000L)
            runCatching {
                NetworkClient.apiClient.newCall(Request.Builder().url(url).build()).execute().use { res ->
                    if (!res.isSuccessful) return@use
                    val body = res.body ?: return@use
                    val parsed = BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536).use { reader ->
                        M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                    }
                    if (parsed.isNotEmpty()) {
                        channelCache.saveChannels(cKey, parsed, maxLimit = maxPlaylistLimit)
                    }
                }
            }
        }
    }

    private suspend fun restoreSavedDataFromBoot(prefs: android.content.SharedPreferences, hasNet: Boolean) {
        if (!autoResumeEnabled) {
            updateBootStage(90, "Preparing Live Television...", "Starting default stream")
            switchChannel(0, immediatePlayback = true)
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
            return
        }

        if (prefs.getBoolean("has_saved_profiles", false)) {
            val savedProfiles = withContext(Dispatchers.IO) { profileStore.all() }
            val activeId = withContext(Dispatchers.IO) { profileStore.activeId() }
            val active = savedProfiles.firstOrNull { it.id == activeId } ?: savedProfiles.firstOrNull()
            if (active != null) {
                profileStore.setActive(active.id)
                if (!hasNet) {
                    updateBootStage(70, "Network unavailable – Loading saved channels.", active.name)
                }
                activateProfile(active)
                return
            }
        }

        val srv = prefs.getString("xtream_server", "") ?: ""
        val usr = prefs.getString("xtream_user", "") ?: ""
        val pwd = prefs.getString("xtream_pass", "") ?: ""
        val m3u = prefs.getString("m3u_url", "") ?: ""
        if (srv.isNotEmpty() && usr.isNotEmpty()) {
            loadXtreamChannels(XtreamCredentials("Saved", srv, usr, pwd), forceNetworkRefresh = false)
        } else if (m3u.isNotEmpty()) {
            loadM3uFromInput(m3u, "Saved M3U", forceNetworkRefresh = false)
        } else {
            updateBootStage(90, "Preparing Live Television...", "Ready to Watch")
            switchChannel(0, immediatePlayback = true)
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
        }
    }

    private fun updateOsdForCurrentChannel() {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return
        val channel = allChannels[currentChannelIndex]
        tvChannelNumber.text = when {
            channel.number < 10 -> "00${channel.number}"
            channel.number < 100 -> "0${channel.number}"
            else -> channel.number.toString()
        }
        tvChannelName.text = channel.name
        if (channel.logoUrl.isNotBlank() && !isDestroyed && !isFinishing) {
            Glide.with(this)
                .load(channel.logoUrl)
                .apply(logoRequestOptions)
                .into(channelLogo)
        } else {
            channelLogo.setImageResource(R.drawable.ic_3d_live_tv)
        }
        val epg = lookupEpgForChannel(channel)
        val telemetrySuffix = if (liveTelemetryDetail.isNotEmpty()) " • $liveTelemetryDetail" else ""
        tvChannelCategory.text = "${channel.category} • $liveResolutionLabel$telemetrySuffix • $liveStatusLabel"
        tvEpgNow.text = "Now: ${epg?.first ?: Channel.DEFAULT_PROGRAM}  •  Next: ${epg?.second ?: Channel.DEFAULT_NEXT_PROGRAM}  •  CH ${currentChannelIndex + 1}/${allChannels.size}"
        updateFavButtonUi(channel.id)
    }

    // Ultra-Fast Zap: Fires ExoPlayer preparation FIRST on millisecond 0 before UI/Glide updates!
    private fun switchChannel(newIndex: Int, immediatePlayback: Boolean = false) {
        if (allChannels.isEmpty()) return
        val resolvedIndex = ((newIndex % allChannels.size) + allChannels.size) % allChannels.size
        val targetChannel = allChannels[resolvedIndex]

        if (::profileStore.isInitialized &&
            profileStore.isCategoryLocked(targetChannel.category) &&
            !unlockedSessionCategories.contains(targetChannel.category.lowercase(Locale.ROOT))
        ) {
            promptParentalPinToUnlock(targetChannel.category) {
                switchChannel(resolvedIndex, immediatePlayback = true)
            }
            return
        }

        if (resolvedIndex != currentChannelIndex) {
            lastZapForward = resolvedIndex > currentChannelIndex ||
                (currentChannelIndex == allChannels.lastIndex && resolvedIndex == 0)
            previousChannelIndex = currentChannelIndex
        }
        currentChannelIndex = resolvedIndex
        val channel = allChannels[currentChannelIndex]
        playbackRetryCount = 0
        stallRecoveryCount = 0
        usingBackupStream = false
        liveTelemetryDetail = ""
        lastSwitchStartElapsedMs = SystemClock.elapsedRealtime()
        liveStatusLabel = "⚡ Zapping..."
        osdLiveProgressBar.progress = 35

        StreamPreFetcher.notifyChannelSwitched(channel.streamUrl, lastZapForward)
        uiHandler.removeCallbacks(stallWatchdogRunnable)
        uiHandler.removeCallbacks(retryPlaybackRunnable)
        uiHandler.removeCallbacks(commitPlaybackRunnable)

        activePlaybackToken++
        val switchToken = activePlaybackToken

        // 1. Fire Media3 ExoPlayer immediately BEFORE any UI/Glide work for minimum zapping latency!
        if (immediatePlayback) {
            startPlaybackForCurrentChannel(forceReload = false)
        } else {
            pendingCommitToken = switchToken
            uiHandler.postDelayed(commitPlaybackRunnable, 25L)
        }

        // 2. Update OSD and Recent list asynchronously
        recentIds.remove(channel.id)
        recentIds.add(0, channel.id)
        if (recentIds.size > 20) recentIds.removeAt(recentIds.lastIndex)
        uiHandler.removeCallbacks(persistStateRunnable)
        uiHandler.postDelayed(persistStateRunnable, 600L)

        updateOsdForCurrentChannel()
        showZappingOsd()

        if (leftChannelDrawer.visibility == View.VISIBLE && activeTab == "RECENT") {
            renderDrawerList()
        } else {
            channelAdapter.updateActiveChannel(currentChannelIndex)
        }
    }

    private fun startPlaybackForCurrentChannel(forceReload: Boolean = false) {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return
        val channel = allChannels[currentChannelIndex]
        if (::profileStore.isInitialized) {
            val savedLang = profileStore.getPreferredAudioLanguage(channel.id)
            if (!savedLang.isNullOrBlank()) {
                exoPlayer?.let { player ->
                    player.trackSelectionParameters = player.trackSelectionParameters
                        .buildUpon()
                        .setPreferredAudioLanguages(savedLang, "hi", "hin", "en", "eng")
                        .build()
                }
            }
        }
        playSpecificStreamUrl(channel.streamUrl, forceReload = forceReload)
    }

    private fun lookupEpgForChannel(channel: Channel): Pair<String, String>? {
        if (epgMap.isEmpty()) return null
        val primaryKey = channel.epgId.ifBlank { channel.id }
        epgMap[primaryKey]?.let { return it }
        epgMap[primaryKey.lowercase(Locale.ROOT)]?.let { return it }
        if (channel.name.isNotBlank()) {
            epgMap[channel.name.lowercase(Locale.ROOT)]?.let { return it }
        }
        return null
    }

    private fun redactUrlForDisplay(raw: String): String {
        return NetworkClient.redactSensitiveUrl(raw).take(48)
    }

    private fun playSpecificStreamUrl(targetUrl: String, forceReload: Boolean = false) {
        exoPlayer?.let { player ->
            if (!forceReload &&
                currentPlayingStreamUrl == targetUrl &&
                (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING)
            ) {
                player.playWhenReady = true
                return
            }
            currentPlayingStreamUrl = targetUrl

            // Preload-to-Playback Handoff: Reuse prepared MediaSource if available and fresh
            val preloadedSource = if (!forceReload) {
                StreamPreFetcher.consumePreparedMediaSource(targetUrl)
            } else {
                null
            }
            if (preloadedSource != null) {
                lastSwitchUsedPreload = true
                player.setMediaSource(preloadedSource, true)
                player.prepare()
                player.playWhenReady = true
                return
            }

            lastSwitchUsedPreload = false
            val mediaItem = StreamPreFetcher.buildLiveMediaItem(targetUrl)
            val hlsFactory = hlsChunklessFactory
            val defFactory = defaultMediaSourceFactory
            if (hlsFactory != null && StreamPreFetcher.detectStreamFormat(targetUrl) == StreamPreFetcher.StreamFormat.HLS) {
                player.setMediaSource(hlsFactory.createMediaSource(mediaItem), true)
            } else if (defFactory != null) {
                player.setMediaSource(defFactory.createMediaSource(mediaItem), true)
            } else {
                player.setMediaItem(mediaItem, true)
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    private fun showZappingOsd() {
        osdBanner.alpha = 1f
        osdBanner.visibility = View.VISIBLE
        topControlBar.visibility = View.VISIBLE
        uiHandler.removeCallbacks(hideOsdRunnable)
        uiHandler.postDelayed(hideOsdRunnable, 3200L)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val isKeyRepeat = (event?.repeatCount ?: 0) > 0
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    lastZapForward = true
                    switchChannel(currentChannelIndex + 1, immediatePlayback = !isKeyRepeat)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    lastZapForward = false
                    switchChannel(currentChannelIndex - 1, immediatePlayback = !isKeyRepeat)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    openDrawerAndRequestFocus()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_LAST_CHANNEL, KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_DEL -> {
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    recallPreviousChannel()
                    return true
                }
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_YELLOW -> {
                showAudioAndQualityDialog()
                return true
            }
            KeyEvent.KEYCODE_PROG_BLUE -> {
                showThemeAndPipDialog()
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                if (leftChannelDrawer.visibility == View.VISIBLE) {
                    closeDrawerAndRestoreFocus()
                    return true
                }
                if (osdBanner.visibility == View.VISIBLE || topControlBar.visibility == View.VISIBLE) {
                    uiHandler.removeCallbacks(hideOsdRunnable)
                    osdBanner.visibility = View.GONE
                    topControlBar.visibility = View.GONE
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (numberInputBuffer.isNotEmpty()) {
                    uiHandler.removeCallbacks(numberJumpRunnable)
                    numberJumpRunnable.run()
                    return true
                }
                if (leftChannelDrawer.visibility != View.VISIBLE) {
                    showZappingOsd()
                    return true
                }
            }
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                val digit = keyCode - KeyEvent.KEYCODE_0
                if (numberInputBuffer.length < 5) {
                    numberInputBuffer += digit.toString()
                }
                tvChannelNumber.text = numberInputBuffer.padStart(3, '-')
                osdBanner.alpha = 1f
                osdBanner.visibility = View.VISIBLE
                uiHandler.removeCallbacks(numberJumpRunnable)
                uiHandler.postDelayed(numberJumpRunnable, 750L)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun registerNetworkCallbackSafe() {
        if (networkCallbackRegistered) return
        val cm = connectivityManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(networkCallback)
            } else {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(req, networkCallback)
            }
            networkCallbackRegistered = true
        } catch (e: Exception) {
            Log.w("StreamX", "NetworkCallback registration warning: ${e.message}")
        }
    }

    private fun unregisterNetworkCallbackSafe() {
        if (!networkCallbackRegistered) return
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            Log.w("StreamX", "NetworkCallback unregister warning: ${e.message}")
        } finally {
            networkCallbackRegistered = false
        }
    }

    override fun onStart() {
        super.onStart()
        registerNetworkCallbackSafe()
        exoPlayer?.let { player ->
            if (player.mediaItemCount > 0) {
                if (player.playbackState == Player.STATE_IDLE) {
                    player.seekToDefaultPosition()
                    player.prepare()
                }
                player.playWhenReady = true
            }
        }
    }

    override fun onStop() {
        super.onStop()
        val inPip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isInPictureInPictureMode else false
        if (!inPip) {
            unregisterNetworkCallbackSafe()
            StreamPreFetcher.cancelAllPrefetches()
            uiHandler.removeCallbacks(stallWatchdogRunnable)
            uiHandler.removeCallbacks(persistStateRunnable)
            persistStateRunnable.run()
            exoPlayer?.pause()
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching {
            Glide.get(this).trimMemory(level)
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
                level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
            ) {
                Glide.get(this).clearMemory()
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                sharedAllocator?.trim()
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching {
            Glide.get(this).clearMemory()
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            sharedAllocator?.trim()
        }
    }

    override fun onDestroy() {
        cancelBootAnimators()
        unregisterNetworkCallbackSafe()
        StreamPreFetcher.cancelAllPrefetches()
        filterJob?.cancel()
        loadChannelsJob?.cancel()
        epgLoadJob?.cancel()
        bgSyncJob?.cancel()
        uiHandler.removeCallbacksAndMessages(null)
        playerView.player = null
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }

    /**
     * 4D Crystal Glass Channel Card Adapter for 512MB RAM Android TVs.
     * Uses zero-XML-inflation programmatic ViewHolders with 3D channel number badges,
     * RGB_565 channel logos (or 3D crystal TV icon), two-line title + EPG/category metadata,
     * and live/favorite badges.
     */
    private class ChannelDrawerAdapter(
        private val channelProvider: (Int) -> Channel?,
        private val isFavorite: (String) -> Boolean,
        private val epgProvider: (Channel) -> String?,
        private val logoOptions: RequestOptions,
        private val onChannelClick: (Int) -> Unit,
        private val onChannelFocused: (Int) -> Unit
    ) : RecyclerView.Adapter<ChannelDrawerAdapter.ChannelViewHolder>() {

        companion object {
            private const val PAYLOAD_ACTIVE_STATE = 1
            private const val PAYLOAD_FAVORITE_STATE = 2
        }

        private var indices: IntArray = IntArray(0)
        private var indicesAscending: Boolean = true
        private var activeGlobalIndex: Int = 0
        private var activeRowDrawableRes: Int = R.drawable.bg_btn_3d_cyan
        private val inactiveRowDrawableRes: Int = R.drawable.bg_channel_row_4d
        private val metaBuilder = StringBuilder(64)

        init {
            setHasStableIds(true)
        }

        fun currentIndices(): IntArray = indices

        private fun findAdapterPos(globalIndex: Int): Int {
            if (indices.isEmpty()) return -1
            if (indicesAscending) {
                val pos = Arrays.binarySearch(indices, globalIndex)
                return if (pos >= 0) pos else -1
            }
            return indices.indexOfFirst { it == globalIndex }
        }

        fun setActiveRowDrawable(drawableRes: Int) {
            if (activeRowDrawableRes == drawableRes) return
            activeRowDrawableRes = drawableRes
            val activePos = findAdapterPos(activeGlobalIndex)
            if (activePos != -1) {
                notifyItemChanged(activePos, PAYLOAD_ACTIVE_STATE)
            }
        }

        fun submitIndices(
            newIndices: IntArray,
            currentGlobalIndex: Int,
            diffResult: DiffUtil.DiffResult?,
            isAscending: Boolean = true
        ) {
            val prevActiveGlobal = activeGlobalIndex
            indices = newIndices
            indicesAscending = isAscending
            activeGlobalIndex = currentGlobalIndex
            if (diffResult != null) {
                diffResult.dispatchUpdatesTo(this)
                if (prevActiveGlobal != currentGlobalIndex) {
                    val oldPos = findAdapterPos(prevActiveGlobal)
                    val newPos = findAdapterPos(currentGlobalIndex)
                    if (oldPos != -1) notifyItemChanged(oldPos, PAYLOAD_ACTIVE_STATE)
                    if (newPos != -1) notifyItemChanged(newPos, PAYLOAD_ACTIVE_STATE)
                }
            } else {
                notifyDataSetChanged()
            }
        }

        fun updateActiveChannel(newGlobalIndex: Int) {
            if (activeGlobalIndex == newGlobalIndex) return
            val oldGlobal = activeGlobalIndex
            activeGlobalIndex = newGlobalIndex
            val oldPos = findAdapterPos(oldGlobal)
            val newPos = findAdapterPos(newGlobalIndex)
            if (oldPos != -1) notifyItemChanged(oldPos, PAYLOAD_ACTIVE_STATE)
            if (newPos != -1) notifyItemChanged(newPos, PAYLOAD_ACTIVE_STATE)
        }

        fun notifyFavoriteChanged(globalIndex: Int) {
            val pos = findAdapterPos(globalIndex)
            if (pos != -1) notifyItemChanged(pos, PAYLOAD_FAVORITE_STATE)
        }

        override fun getItemId(position: Int): Long = indices[position].toLong()

        private fun dp(ctx: Context, v: Int): Int =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
            val ctx = parent.context
            val root = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(inactiveRowDrawableRes)
                setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(ctx, 7)
                }
            }

            val tvNum = TextView(ctx).apply {
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#38BDF8"))
                setBackgroundResource(R.drawable.bg_badge_neon)
                gravity = Gravity.CENTER
                minWidth = dp(ctx, 42)
                setPadding(dp(ctx, 7), dp(ctx, 4), dp(ctx, 7), dp(ctx, 4))
            }
            root.addView(tvNum)

            val ivLogo = ImageView(ctx).apply {
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(ctx, 4), dp(ctx, 4), dp(ctx, 4), dp(ctx, 4))
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageResource(R.drawable.ic_3d_live_tv)
                layoutParams = LinearLayout.LayoutParams(dp(ctx, 34), dp(ctx, 34)).apply {
                    marginStart = dp(ctx, 8)
                }
            }
            root.addView(ivLogo)

            val textCol = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(ctx, 9)
                    marginEnd = dp(ctx, 6)
                }
            }
            val tvTitle = TextView(ctx).apply {
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvSub = TextView(ctx).apply {
                textSize = 10.5f
                setTextColor(Color.parseColor("#BAE6FD"))
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvTitle)
            textCol.addView(tvSub)
            root.addView(textCol)

            val tvFavBadge = TextView(ctx).apply {
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#FDE047"))
                setPadding(dp(ctx, 4), dp(ctx, 2), dp(ctx, 4), dp(ctx, 2))
            }
            root.addView(tvFavBadge)

            return ChannelViewHolder(root, tvNum, ivLogo, tvTitle, tvSub, tvFavBadge, onChannelClick, onChannelFocused)
        }

        override fun onBindViewHolder(
            holder: ChannelViewHolder,
            position: Int,
            payloads: MutableList<Any>
        ) {
            if (payloads.isEmpty()) {
                onBindViewHolder(holder, position)
                return
            }
            val globalIdx = indices[position]
            val ch = channelProvider(globalIdx) ?: return
            val isSelected = globalIdx == activeGlobalIndex
            for (payload in payloads) {
                when (payload) {
                    PAYLOAD_ACTIVE_STATE -> {
                        holder.root.setBackgroundResource(if (isSelected) activeRowDrawableRes else inactiveRowDrawableRes)
                        bindBadgeState(holder, ch, isSelected)
                    }
                    PAYLOAD_FAVORITE_STATE -> {
                        bindBadgeState(holder, ch, isSelected)
                    }
                }
            }
        }

        override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
            val globalIdx = indices[position]
            holder.boundGlobalIndex = globalIdx
            val ch = channelProvider(globalIdx) ?: return
            val isSelected = globalIdx == activeGlobalIndex

            holder.tvNum.text = when {
                ch.number < 10 -> "00${ch.number}"
                ch.number < 100 -> "0${ch.number}"
                else -> ch.number.toString()
            }
            holder.tvTitle.text = ch.name

            metaBuilder.setLength(0)
            metaBuilder.append(ch.category)
            val nowProg = epgProvider(ch)
            if (!nowProg.isNullOrBlank()) {
                metaBuilder.append(" • ").append(nowProg)
            } else if (ch.backupUrl.isNotBlank()) {
                metaBuilder.append(" • ⚡ Dual-Stream")
            } else {
                metaBuilder.append(" • Live HD")
            }
            holder.tvSub.text = metaBuilder.toString()

            if (ch.logoUrl.isNotBlank()) {
                Glide.with(holder.ivLogo.context)
                    .load(ch.logoUrl)
                    .apply(logoOptions)
                    .into(holder.ivLogo)
            } else {
                Glide.with(holder.ivLogo.context).clear(holder.ivLogo)
                holder.ivLogo.setImageResource(R.drawable.ic_3d_live_tv)
            }

            holder.root.setBackgroundResource(if (isSelected) activeRowDrawableRes else inactiveRowDrawableRes)
            bindBadgeState(holder, ch, isSelected)
        }

        private fun bindBadgeState(holder: ChannelViewHolder, ch: Channel, isSelected: Boolean) {
            val fav = isFavorite(ch.id)
            when {
                isSelected && fav -> {
                    holder.tvFavBadge.text = "★ LIVE"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#FDE047"))
                }
                isSelected -> {
                    holder.tvFavBadge.text = "● LIVE"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#6EE7B7"))
                }
                fav -> {
                    holder.tvFavBadge.text = "★"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#FDE047"))
                }
                else -> {
                    holder.tvFavBadge.text = ""
                }
            }
        }

        override fun getItemCount(): Int = indices.size

        class ChannelViewHolder(
            val root: LinearLayout,
            val tvNum: TextView,
            val ivLogo: ImageView,
            val tvTitle: TextView,
            val tvSub: TextView,
            val tvFavBadge: TextView,
            onChannelClick: (Int) -> Unit,
            onChannelFocused: (Int) -> Unit
        ) : RecyclerView.ViewHolder(root) {
            var boundGlobalIndex: Int = -1

            init {
                root.setOnClickListener {
                    if (boundGlobalIndex >= 0) {
                        onChannelClick(boundGlobalIndex)
                    }
                }
                root.setOnFocusChangeListener { _, hasFocus ->
                    if (hasFocus && boundGlobalIndex >= 0) {
                        onChannelFocused(boundGlobalIndex)
                    }
                }
            }
        }
    }
}
