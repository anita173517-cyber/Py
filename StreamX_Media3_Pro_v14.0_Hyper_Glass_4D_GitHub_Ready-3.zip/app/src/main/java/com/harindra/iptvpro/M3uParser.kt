package com.harindra.iptvpro

import java.io.BufferedReader
import java.io.Reader
import java.io.StringReader

object M3uParser {
    private const val DEFAULT_MAX_CHANNELS = 60_000
    private const val FIRST_BATCH_SIZE = 80 // Emit the first 80 channels early for progressive loading

    private fun extractAttributeFast(line: String, attrName: String): String {
        val keyIdx = line.indexOf(attrName, startIndex = 8, ignoreCase = true)
        if (keyIdx < 0) return ""
        var i = keyIdx + attrName.length
        val len = line.length
        while (i < len && line[i].isWhitespace()) i++
        if (i >= len || line[i] != '=') return ""
        i++
        while (i < len && line[i].isWhitespace()) i++
        if (i >= len) return ""
        val quote = line[i]
        if (quote != '"' && quote != '\'') return ""
        val start = i + 1
        val end = line.indexOf(quote, startIndex = start)
        return if (end > start) line.substring(start, end).trim() else ""
    }

    fun fnv1a64(str: String): Long {
        var hash = -0x340d631b7bdddcdbL
        for (i in 0 until str.length) {
            hash = hash xor str[i].code.toLong()
            hash *= 0x100000001b3L
        }
        return hash
    }

    /**
     * Zero-allocation 64-bit case-insensitive FNV-1a composite hash of (group, '|', name).
     * Eliminates 30,000+ temporary lowercase/concatenated String allocations when parsing 10,000+ channels.
     */
    fun fnv1a64NormalizedPair(group: String, name: String): Long {
        var hash = -0x340d631b7bdddcdbL
        var gStart = 0
        var gEnd = group.length - 1
        while (gStart <= gEnd && group[gStart].isWhitespace()) gStart++
        while (gEnd >= gStart && group[gEnd].isWhitespace()) gEnd--
        for (i in gStart..gEnd) {
            hash = hash xor group[i].lowercaseChar().code.toLong()
            hash *= 0x100000001b3L
        }
        hash = hash xor '|'.code.toLong()
        hash *= 0x100000001b3L
        var nStart = 0
        var nEnd = name.length - 1
        while (nStart <= nEnd && name[nStart].isWhitespace()) nStart++
        while (nEnd >= nStart && name[nEnd].isWhitespace()) nEnd--
        for (i in nStart..nEnd) {
            hash = hash xor name[i].lowercaseChar().code.toLong()
            hash *= 0x100000001b3L
        }
        return hash
    }

    fun parse(
        m3uContent: String,
        maxChannels: Int = DEFAULT_MAX_CHANNELS,
        shouldCancel: () -> Boolean = { false },
        onFirstBatch: ((List<Channel>) -> Unit)? = null
    ): List<Channel> {
        return parse(StringReader(m3uContent.removePrefix("\uFEFF")), maxChannels, shouldCancel, onFirstBatch)
    }

    fun parse(
        reader: Reader,
        maxChannels: Int = DEFAULT_MAX_CHANNELS,
        shouldCancel: () -> Boolean = { false },
        onFirstBatch: ((List<Channel>) -> Unit)? = null
    ): List<Channel> {
        val channels = ArrayList<Channel>(4096)
        val categoryPool = HashMap<String, String>(128)
        val seenUrlHashes = HashSet<Long>(4096)
        val primaryIndexByNormHash = HashMap<Long, Int>(4096)
        val pendingHeaders = LinkedHashMap<String, String>(4)

        var pendingName = ""
        var pendingGroup = "General"
        var pendingLogo = ""
        var pendingId = ""
        var number = 1
        var lineCounter = 0
        var firstBatchEmitted = false

        val buffered = if (reader is BufferedReader) reader else BufferedReader(reader, 65536)
        var rawLine: String? = buffered.readLine()
        while (rawLine != null) {
            lineCounter++
            if (lineCounter % 1500 == 0 && shouldCancel()) {
                break
            }
            val line = rawLine.trim().let { if (lineCounter == 1) it.removePrefix("\uFEFF") else it }
            if (line.isNotEmpty()) {
                when {
                    line.startsWith("#EXTINF:", ignoreCase = true) -> {
                        val comma = line.lastIndexOf(',')
                        pendingName = if (comma >= 0 && comma < line.lastIndex) {
                            line.substring(comma + 1).trim()
                        } else {
                            "Channel $number"
                        }
                        val rawGroup = extractAttributeFast(line, "group-title").ifBlank { "General" }
                        pendingGroup = categoryPool.getOrPut(rawGroup) { rawGroup }
                        pendingLogo = extractAttributeFast(line, "tvg-logo")
                        pendingId = extractAttributeFast(line, "tvg-id")
                        val inlineUa = extractAttributeFast(line, "http-user-agent")
                        if (inlineUa.isNotEmpty()) pendingHeaders["User-Agent"] = inlineUa
                        val inlineRef = extractAttributeFast(line, "http-referrer")
                            .ifEmpty { extractAttributeFast(line, "http-referer") }
                        if (inlineRef.isNotEmpty()) pendingHeaders["Referer"] = inlineRef
                    }
                    line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                        val rawGroup = line.substringAfter(':').trim().ifBlank { "General" }
                        pendingGroup = categoryPool.getOrPut(rawGroup) { rawGroup }
                    }
                    line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                        val opt = line.substringAfter(':').trim()
                        when {
                            opt.startsWith("http-user-agent=", ignoreCase = true) -> {
                                val ua = opt.substringAfter('=').trim()
                                if (ua.isNotEmpty()) pendingHeaders["User-Agent"] = ua
                            }
                            opt.startsWith("http-referrer=", ignoreCase = true) ||
                                opt.startsWith("http-referer=", ignoreCase = true) -> {
                                val ref = opt.substringAfter('=').trim()
                                if (ref.isNotEmpty()) pendingHeaders["Referer"] = ref
                            }
                        }
                    }
                    line.startsWith("#KODIPROP:", ignoreCase = true) -> {
                        val prop = line.substringAfter(':').trim()
                        if (prop.startsWith("inputstream.adaptive.stream_headers=", ignoreCase = true)) {
                            val hdrs = prop.substringAfter('=').trim()
                            for (pair in hdrs.split('&')) {
                                val eq = pair.indexOf('=')
                                if (eq > 0) {
                                    pendingHeaders[pair.substring(0, eq).trim()] = pair.substring(eq + 1).trim()
                                }
                            }
                        }
                    }
                    !line.startsWith("#") && (
                        line.startsWith("http://", ignoreCase = true) ||
                            line.startsWith("https://", ignoreCase = true) ||
                            line.startsWith("rtsp://", ignoreCase = true) ||
                            line.startsWith("rtmp://", ignoreCase = true) ||
                            line.startsWith("udp://", ignoreCase = true) ||
                            line.startsWith("rtp://", ignoreCase = true)
                        ) -> {
                        val cleanUrl = if (line.indexOf('|') > 0 || pendingHeaders.isNotEmpty()) {
                            NetworkClient.extractCleanUrlAndRegisterHeaders(line, pendingHeaders)
                        } else {
                            line
                        }
                        if (cleanUrl.isNotEmpty() && seenUrlHashes.add(fnv1a64(cleanUrl))) {
                            val resolvedName = pendingName.ifBlank { "Channel $number" }
                            val normHash = fnv1a64NormalizedPair(pendingGroup, resolvedName)
                            val existingIdx = primaryIndexByNormHash[normHash]
                            if (existingIdx != null && existingIdx in channels.indices && channels[existingIdx].backupUrl.isEmpty()) {
                                val primary = channels[existingIdx]
                                channels[existingIdx] = primary.copy(backupUrl = cleanUrl)
                            } else {
                                val newIdx = channels.size
                                channels.add(
                                    Channel(
                                        id = if (pendingId.isNotEmpty()) "${pendingId}_$number" else "m3u_$number",
                                        number = number,
                                        name = resolvedName,
                                        category = pendingGroup,
                                        streamUrl = cleanUrl,
                                        logoUrl = pendingLogo,
                                        epgId = pendingId
                                    )
                                )
                                primaryIndexByNormHash.putIfAbsent(normHash, newIdx)
                                number++
                                if (!firstBatchEmitted && channels.size == FIRST_BATCH_SIZE && onFirstBatch != null) {
                                    firstBatchEmitted = true
                                    onFirstBatch(ArrayList(channels))
                                }
                                if (channels.size >= maxChannels) break
                            }
                        }
                        pendingName = ""
                        pendingGroup = "General"
                        pendingLogo = ""
                        pendingId = ""
                        pendingHeaders.clear()
                    }
                }
            }
            rawLine = buffered.readLine()
        }
        return channels
    }
}
